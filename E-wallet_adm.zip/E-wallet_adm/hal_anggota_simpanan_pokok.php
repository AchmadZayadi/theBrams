<?php include "../proses/koneksi.php";
session_start();

$id = $_SESSION['nama'];
	$nama = $_SESSION['namaang'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<title>Kopkar</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	
<!--===============================================================================================-->	
	<link rel="icon" type="image/png" href="images/icons/favicon.ico"/>
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/bootstrap/css/bootstrap.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/iconic/css/material-design-iconic-font.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/animate/animate.css">
<!--===============================================================================================-->	
	<link rel="stylesheet" type="text/css" href="vendor/css-hamburgers/hamburgers.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/animsition/css/animsition.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/select2/select2.min.css">
<!--===============================================================================================-->	
	<link rel="stylesheet" type="text/css" href="vendor/daterangepicker/daterangepicker.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="css/util.css">
	<link rel="stylesheet" type="text/css" href="css/main.css">
<!--===============================================================================================-->
</head>
<body>

<?php
                      
                       $raw_results = mysqli_query($connect, "select * from tb_anggota where status='Menunggu Pembayaran'") or die(mysql_error());
                        if (mysqli_num_rows($raw_results) == 0) {
                       
                             echo "<script>window.location = '../admin/hal_anggota.php'</script>";
					
                        }
                        else{
                       ?>
					   <div class="row" style="margin-left: 300px; padding-top: 30px;">
	<div class="content pb-0">
	<div class="content">
            <div class="animated fadeIn">
                <div class="row">
                    <div class="col-12">
                        <div class="card">
						<div class="card-header">
                                <strong class="card-title">Tambah Simpanan Pokok</strong>
                            </div>
                            <div class="container">
                <div class="row">
                
                <div class=" col-md-9 col-lg-9 ">
                     <?php
                              $query2 = "SELECT max(id_simpanan) as maxid FROM tb_simpanan";
                        $hasil = mysqli_query($connect, $query2)or die(mysqli_error());
                        $hslidmax = mysqli_fetch_array($hasil);
                        $idmax = $hslidmax['maxid']; 
                        $nourut = (int) substr($idmax, 2,4);

                        $nourut++;

                        $newID = 'S' . sprintf('%03s', $nourut);
                                ?>
								<form action="../proses/anggota_tambah_simpanan_pokok.php" method="post" enctype="multipart/form-data">
                  <table class="table table-user-information">
                    <tbody>
                      <tr>
                          <td><label for="id_simpanan">ID Simpanan</label></td>
                          <td><input name="id_simpanan" type="text" class="form-control" id="id_simpanan" value="<?php echo $newID;?>" placeholder="ID Simpanan" readonly="readonly"/></td>
                      </tr>
                      <tr>
                          <td><label for="id_anggota">ID Anggota</label></td>
                          <td><input name="id_anggota" type="text" class="form-control" id="id_anggota" value="<?php echo $_SESSION['nama'];?>" placeholder="ID Anggota" readonly="readonly"/></td>
                      </tr>
                      <tr>
                          <td><label for="nama">Nama</label></td>
                          <td><input name="nama" type="text" class="form-control" id="nama" value="<?php echo $nama;?>" placeholder="Nama" readonly="readonly"/></td>
                      </tr><tr>
                          <td><label for="jenis_simpanan">Jenis Simpanan</label></td>
                          <td><input name="jenis_simpanan" type="text" class="form-control" id="jenis_simpanan" value="POKOK" placeholder="Jenis Simpanan" readonly="readonly"/></td>
                      </tr>
                      <tr>
                          <td><label for="tanggal">Tanggal</label></td>
                          <td><input name="tanggal" type="date" class="form-control" id="theDate" placeholder="tanggal" readonly="readonly"/></td>
                      </tr>
					  <tr>
                          <td><label for="nominal">Nominal</label></td>
                          <td><input name="nominal" type="text" class="form-control" id="nominal" value="50000" placeholder="Nominal" readonly="readonly"/></td>
                      </tr>
					  <tr>
                          <td><label for="file_struk">Upload Struk</label></td>
                          <td><input type="file" class="form-control" multiple="" name="file_struk" id="file_struk" required /></td>
                      </tr>
                      <tr>
							<td style="width: 300px;"><input type="submit" name="submit" value="Simpan Data"  class="btn btn-sm btn-primary"/>&nbsp;<a href="login.php" class="btn btn-sm btn-primary">Kembali</a></td>
					  </tr>
               
                    </tbody>
                  </table>
				  </form>
                
                </div>
            </div>
            </div>
			</div>
            </div>
            </div><!-- .animated -->
        </div><!-- .content -->

        </div>
		</div>
		</div>
	 <?php
                        }
                        ?>

	<div id="dropDownSelect1"></div>
	
<!--===============================================================================================-->
	<script src="vendor/jquery/jquery-3.2.1.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/animsition/js/animsition.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/bootstrap/js/popper.js"></script>
	<script src="vendor/bootstrap/js/bootstrap.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/select2/select2.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/daterangepicker/moment.min.js"></script>
	<script src="vendor/daterangepicker/daterangepicker.js"></script>
<!--===============================================================================================-->
	<script src="vendor/countdowntime/countdowntime.js"></script>
<!--===============================================================================================-->
	<script src="js/main.js"></script>
	
	<script type="text/javascript">
        $(document).ready(function() {
          $('#bootstrap-data-table-export').DataTable();
      } );
	  
	  var date = new Date();

	var day = date.getDate();
	var month = date.getMonth() + 1;
	var year = date.getFullYear();

	if (month < 10) month = "0" + month;
	if (day < 10) day = "0" + day;

	var today = year + "-" + month + "-" + day;


	document.getElementById('theDate').value = today;
  </script>

</body>
</html>