<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title></title>
    <meta name="description" content="Ela Admin - HTML5 Admin Template">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="apple-touch-icon" href="images/fav.png">
    <link rel="shortcut icon" href="images/fav.png">

    <link rel="stylesheet" href="assets/css/normalize.css">
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/font-awesome.min.css">
    <link rel="stylesheet" href="assets/css/themify-icons.css">
    <link rel="stylesheet" href="assets/css/pe-icon-7-filled.css">


    <link href="assets/weather/css/weather-icons.css" rel="stylesheet" />
    <link href="assets/calendar/fullcalendar.css" rel="stylesheet" />

    <link rel="stylesheet" href="assets/css/style.css">
    <link href="assets/css/charts/chartist.min.css" rel="stylesheet"> 
    <link href="assets/css/lib/vector-map/jqvmap.min.css" rel="stylesheet"> 


    <style>
    #weatherWidget .currentDesc {
        color: #ffffff!important;
    }
        .traffic-chart { 
            min-height: 335px; 
        }
        #flotPie1  {
            height: 150px;
        } 
        #flotPie1 td {
            padding:3px;
        }
        #flotPie1 table {
            top: 20px!important;
            right: -10px!important;
        }
        .chart-container {
            display: table;
            min-width: 270px ;
            text-align: left;
            padding-top: 10px;
            padding-bottom: 10px;
        }
        #flotLine5  {
             height: 105px;
        } 

        #flotBarChart {
            height: 150px;
        }
        #cellPaiChart{
            height: 160px;
        }

    </style>

</head>						
										<TABLE WIDTH="100%">
											<TR>
											<BR><TD ALIGN="CENTER" WIDTH="20%"><img style="width:150px; margin-top: 10px;" src="images/k.png" alt="..." class="img-circle"></TD><BR>
											<BR><TD ALIGN="CENTER" WIDTH="180%"><FONT SIZE="6"><b>LAPORAN ANGSURAN BULANAN</b><BR>
													<b>KOPERASI KARYAWAN</b><BR>
													<b>PT. HONDA PRECISION PARTS MANUFACTURING</b><BR>		
												</TD>
                                        </TABLE><BR><BR><BR>
                                                <hr>
                                                <div class="table-responsive">
                                                    <?php
													 include "../proses/koneksi.php";
                                                    $tampil = ("SELECT tb_angsuran.id_angsuran, tb_anggota.nama, tb_angsuran.nominal_simpanan, tb_angsuran.tanggal, tb_angsuran.angsuran_ke, tb_angsuran.id_anggota, tb_angsuran.id_peminjaman, tb_pengajuan.id_pengajuan, tb_angsuran.id_anggota, tb_angsuran.angsuran_ke, tb_angsuran.jumlah_angsuran, tb_angsuran.nominal_peminjaman, tb_angsuran.jenis_pinjaman, tb_pengajuan.jangka_waktu FROM tb_anggota, tb_pengajuan, tb_angsuran, tb_peminjaman WHERE tb_anggota.id_anggota = tb_angsuran.id_anggota And tb_angsuran.id_anggota = tb_pengajuan.id_anggota AND tb_peminjaman.id_anggota = tb_anggota.id_anggota AND tb_peminjaman.id_peminjaman = tb_angsuran.id_peminjaman");
                                                    $result = mysqli_query($connect, $tampil)or die(mysqli_error());
                                                   ?>
													<table class="table table-condensed ">
                                                        <?php while ($data = mysqli_fetch_array($result)) {
														?>
														
                                                        </table>
                                                         <div class="text-Left">
														
														 <?php
														$mulai_tgl	= $_POST['mulai_tgl'];
														$sampai_tgl 	= $_POST['sampai_tgl']; 
														 
                                    $tampil = ("SELECT tb_angsuran.id_angsuran, tb_anggota.nama, tb_angsuran.nominal_simpanan, tb_angsuran.tanggal, tb_angsuran.angsuran_ke, tb_angsuran.id_anggota, tb_angsuran.id_peminjaman, tb_pengajuan.id_pengajuan, tb_angsuran.id_anggota, tb_angsuran.angsuran_ke, tb_angsuran.jumlah_angsuran, tb_angsuran.nominal_peminjaman, tb_angsuran.jenis_pinjaman, tb_pengajuan.jangka_waktu FROM tb_anggota, tb_pengajuan, tb_angsuran, tb_peminjaman WHERE tb_anggota.id_anggota = tb_angsuran.id_anggota And tb_angsuran.id_anggota = tb_pengajuan.id_anggota AND tb_angsuran.tanggal BETWEEN '$mulai_tgl' AND '$sampai_tgl' AND tb_peminjaman.id_anggota = tb_anggota.id_anggota AND tb_peminjaman.id_peminjaman = tb_angsuran.id_peminjaman");
                                    $result = mysqli_query($connect, $tampil)or die(mysqli_error());
                                    ?>
                                <table  class="table table-striped table-bordered">
                                    <thead>
									
                                        <tr>
											<th>ID Angsuran</th>
                                            <th>ID Anggota</th>
											<th>Nama</th>
											<th>Nominal Simpanan</th>
                                            <th>Jenis Pinjaman</th>
											<th>Nominal Pinjaman</th>
                                            <th>Angsuran Ke</th>
											<th>Tanggal Angsuran</th>
											<th>Jumlah Angsuran</th>
                                        </tr>
                                    </thead>
                                    <tbody>
									<?php while ($row = mysqli_fetch_array($result)) {
                                                ?>
                                        <tr>
											<td><?php echo $row['id_angsuran']; ?></td>
                                            <td><?php echo $row['id_anggota']; ?></td>
                                            <td><?php echo $row['nama']; ?></td>
											<td><?php echo $row['nominal_simpanan']; ?></td>
                                            <td><?php echo $row['jenis_pinjaman']; ?></td>
											<td><?php echo $row['nominal_peminjaman']; ?></td>
											<td><?php echo $row['angsuran_ke']; ?></td>
											<td><?php echo $row['tanggal']; ?></td>
											<td><?php echo $row['jumlah_angsuran']; ?></td>
                                        </tr>
									<?php }?>
                                    </tbody>
                                </table>
														</div>
														
                                                    </div>
                                                    

                                                    <?php
                                                }
                                                ?>
                                                <br />
                                                <br />
                                                <div class="text-right">
                                                    <a href="#" onclick="  window.print(); return true"  id="tombol" class="btn btn-sm btn-primary">Print<i class="fa fa-print"></i></a>
                                                    <a href="hal_ketua_download_laporan.php" id="tombol" class="btn btn-sm btn-primary">Kembali<i class="fa fa-backward"></i></a>
                                                </div>
                                                </div> 
                      </div><!-- /#right-panel -->


     <script src="assets/js/vendor/jquery-2.1.4.min.js"></script>
    <script src="assets/js/popper.min.js"></script>
    <script src="assets/js/plugins.js"></script>
    <script src="assets/js/main.js"></script>


    <script src="assets/js/lib/data-table/datatables.min.js"></script>
    <script src="assets/js/lib/data-table/dataTables.bootstrap.min.js"></script>
    <script src="assets/js/lib/data-table/dataTables.buttons.min.js"></script>
    <script src="assets/js/lib/data-table/buttons.bootstrap.min.js"></script>
    <script src="assets/js/lib/data-table/jszip.min.js"></script>
    <script src="assets/js/lib/data-table/pdfmake.min.js"></script>
    <script src="assets/js/lib/data-table/vfs_fonts.js"></script>
    <script src="assets/js/lib/data-table/buttons.html5.min.js"></script>
    <script src="assets/js/lib/data-table/buttons.print.min.js"></script>
    <script src="assets/js/lib/data-table/buttons.colVis.min.js"></script>
    <script src="assets/js/lib/data-table/datatables-init.js"></script>

<style>
                                                    @media print{
                                                        #tombol{
                                                            display:none;
                                                        }
														 #headera{
                                                            display:none;
                                                        }
														 #samping{
                                                            display:none;
                                                        }
													
                                                    }
                                                </style>
    <script type="text/javascript">
        $(document).ready(function() {
          $('#bootstrap-data-table-export').DataTable();
      } );
  </script>