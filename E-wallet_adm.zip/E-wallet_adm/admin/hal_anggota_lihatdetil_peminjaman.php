<!doctype html>
<html class="no-js" lang=""> <!--<![endif]-->
<?php
session_start();
if (!isset($_SESSION['nama'])) {
    die("Anda belum login"); //
    echo "<input class='btn btn-blue' type=button value='ULANGI LAGI' onclick=location.href='login.php'></a></center>";
} elseif ($_SESSION['level'] == 'anggota') {
    die("Anda bukan anggota"); //
    echo "<input class='btn btn-blue' type=button value='ULANGI LAGI' onclick=location.href='login.php'></a></center>";
}

//cek level user
else {
    include "../proses/koneksi.php";
    ?>
	<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>KopKar | Anggota</title>
    <meta name="description" content="Ela Admin - HTML5 Admin Template">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="apple-touch-icon" href="images/fav.png">
    <link rel="shortcut icon" href="images/fav.png">

    <link rel="stylesheet" href="assets/css/normalize.css">
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/font-awesome.min.css">
    <link rel="stylesheet" href="assets/css/themify-icons.css">
    <link rel="stylesheet" href="assets/css/pe-icon-7-filled.css">


    <link href="assets/weather/css/weather-icons.css" rel="stylesheet" />
    <link href="assets/calendar/fullcalendar.css" rel="stylesheet" />

    <link rel="stylesheet" href="assets/css/style.css">
    <link href="assets/css/charts/chartist.min.css" rel="stylesheet"> 
    <link href="assets/css/lib/vector-map/jqvmap.min.css" rel="stylesheet"> 


    <style>
    #weatherWidget .currentDesc {
        color: #ffffff!important;
    }
        .traffic-chart { 
            min-height: 335px; 
        }
        #flotPie1  {
            height: 150px;
        } 
        #flotPie1 td {
            padding:3px;
        }
        #flotPie1 table {
            top: 20px!important;
            right: -10px!important;
        }
        .chart-container {
            display: table;
            min-width: 270px ;
            text-align: left;
            padding-top: 10px;
            padding-bottom: 10px;
        }
        #flotLine5  {
             height: 105px;
        } 

        #flotBarChart {
            height: 150px;
        }
        #cellPaiChart{
            height: 160px;
        }

    </style>

</head>
<body>

<?php } ?>
    <?php include"side_nav_anggota.php"?>


    <!-- Right Panel --> 
    <div id="right-panel" class="right-panel">

        <!-- Header-->
        <header id="header" class="header">  
            <div class="top-left">
                <div class="navbar-header"> 
                    <a class="navbar-brand" href=""><img src="images/log.png" alt="Logo"></a>
                    <a class="navbar-brand hidden" href=""><img src="images/log.png" alt="Logo"></a> 
                    <a id="menuToggle" class="menutoggle"><i class="fa fa-bars"></i></a> 
                </div> 
            </div>
            <div class="top-right"> 
                <div class="header-menu"> 
                    <div class="header-left">
                        <button class="search-trigger"><i class="fa fa-search"></i></button>
                        <div class="form-inline">
                            <form class="search-form">
                                <input class="form-control mr-sm-2" type="text" placeholder="Search ..." aria-label="Search">
                                <button class="search-close" type="submit"><i class="fa fa-close"></i></button>
                            </form>
                        </div>

                        <div class="dropdown for-notification">
                            <button class="btn btn-secondary dropdown-toggle" type="button" id="notification" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <i class="fa fa-bell"></i>
                                <span class="count bg-danger">3</span>
                            </button>
                            <div class="dropdown-menu" aria-labelledby="notification">
                                <p class="red">You have 3 Notification</p>
                                <a class="dropdown-item media" href="#">
                                    <i class="fa fa-check"></i>
                                    <p>Server #1 overloaded.</p>
                                </a>
                                <a class="dropdown-item media" href="#">
                                    <i class="fa fa-info"></i>
                                    <p>Server #2 overloaded.</p>
                                </a>
                                <a class="dropdown-item media" href="#">
                                    <i class="fa fa-warning"></i>
                                    <p>Server #3 overloaded.</p>
                                </a>
                            </div>
                        </div>

                        <div class="dropdown for-message">
                            <button class="btn btn-secondary dropdown-toggle" type="button" id="message" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <i class="fa fa-envelope"></i>
                                <span class="count bg-primary">4</span>
                            </button>
                            <div class="dropdown-menu" aria-labelledby="message">
                                <p class="red">You have 4 Mails</p>
                                <a class="dropdown-item media" href="#">
                                    <span class="photo media-left"><img alt="avatar" src="images/avatar/1.jpg"></span>
                                    <div class="message media-body">
                                        <span class="name float-left">Jonathan Smith</span>
                                        <span class="time float-right">Just now</span>
                                        <p>Hello, this is an example msg</p>
                                    </div>
                                </a>
                                <a class="dropdown-item media" href="#">
                                    <span class="photo media-left"><img alt="avatar" src="images/avatar/2.jpg"></span>
                                    <div class="message media-body">
                                        <span class="name float-left">Jack Sanders</span>
                                        <span class="time float-right">5 minutes ago</span>
                                        <p>Lorem ipsum dolor sit amet, consectetur</p>
                                    </div>
                                </a>
                                <a class="dropdown-item media" href="#">
                                    <span class="photo media-left"><img alt="avatar" src="images/avatar/3.jpg"></span>
                                    <div class="message media-body">
                                        <span class="name float-left">Cheryl Wheeler</span>
                                        <span class="time float-right">10 minutes ago</span>
                                        <p>Hello, this is an example msg</p>
                                    </div>
                                </a>
                                <a class="dropdown-item media" href="#">
                                    <span class="photo media-left"><img alt="avatar" src="images/avatar/4.jpg"></span>
                                    <div class="message media-body">
                                        <span class="name float-left">Rachel Santos</span>
                                        <span class="time float-right">15 minutes ago</span>
                                        <p>Lorem ipsum dolor sit amet, consectetur</p>
                                    </div>
                                </a>
                            </div>
                        </div>
                    </div>

                    <div class="user-area dropdown float-right">
                        <a href="#" class="dropdown-toggle active" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <img class="user-avatar rounded-circle" src="images/admin.jpg" alt="User Avatar">
                        </a>

                        <div class="user-menu dropdown-menu">
                            <a class="nav-link" href=""><i class="fa fa-user"></i><?php echo $_SESSION['nama']; ?></a>

                            <a class="nav-link" href="#"><i class="fa fa-bell-o"></i>Notifications <span class="count">13</span></a>

                            <a class="nav-link" href="#"><i class="fa fa-cog"></i>Settings</a>

                            <a class="nav-link" href="../proses/logout.php"><i class="fa fa-power-off"></i>Logout</a>
                        </div>
                    </div> 
                </div>  
            </div>
        </header><!-- /header -->
        <!-- Header-->


        <div class="content pb-0">

            <div class="content">
            <div class="animated fadeIn">
                <div class="row">
                    <div class="col-12">
                        <div class="card">
						<div class="card-header">
                                <strong class="card-title">Data Peminjaman</strong>
                            </div>
                            <div class="container">
                <div class="row">
                
                <div class=" col-md-9 col-lg-9 ">  
                     <?php
                                $query = ("SELECT tb_peminjaman.id_peminjaman, tb_pengajuan.id_pengajuan,tb_anggota.nama,tb_peminjaman.tanggal_peminjaman,tb_peminjaman.id_admin, tb_pengajuan.status, tb_angsuran.id_angsuran, tb_anggota.id_anggota, tb_peminjaman.jenis_pinjaman, tb_angsuran.angsuran_ke, tb_peminjaman.nominal, tb_peminjaman.biaya_perbulan, tb_pengajuan.jangka_waktu FROM tb_anggota, tb_pengajuan, tb_peminjaman, tb_angsuran WHERE tb_pengajuan.id_pengajuan = tb_peminjaman.id_pengajuan AND tb_angsuran.id_peminjaman = tb_peminjaman.id_peminjaman AND tb_anggota.id_anggota = tb_angsuran.id_anggota AND tb_peminjaman.id_anggota = tb_anggota.id_anggota and tb_pengajuan.id_anggota AND tb_peminjaman.id_peminjaman='$_GET[kd]'");
                                $result = mysqli_query($connect, $query)or die(mysqli_error());
                                $data = mysqli_fetch_array($result);
								$angsuran_ke = $data['angsuran_ke'];
								$jangka_waktu = $data['jangka_waktu'];
								$sisa_angsur = $jangka_waktu - $angsuran_ke;
                                ?>
                  <table class="table table-user-information">
                    <tbody>
                      <tr>
                        <td>ID Peminjaman :</td>
                        <td><input name="id_peminjaman" type="text" class="form-control" id="id_peminjaman" value="<?php echo $data['id_peminjaman'];?>" placeholder="ID Peminjaman"  readonly = "readonly" /></td>
                      </tr>
                      <tr>
                        <td>ID Pengajuan :</td>
                        <td><input name="id_pengajuan" type="text" class="form-control" id="id_pengajuan" value="<?php echo $data['id_pengajuan'];?>" placeholder="ID Pengajuan"  readonly = "readonly" /></td>
                      </tr>
                      <tr>
                        <td>ID Admin :</td>
                        <td><input name="id_admin" type="text" class="form-control" id="id_admin" value="<?php echo $data['id_admin'];?>" placeholder="ID Admin"  readonly = "readonly" /></td>
                      </tr>
                      <tr>
                        <td>ID Anggota :</td>
                        <td><input name="id_anggota" type="text" class="form-control" id="id_anggota" value="<?php echo $data['id_anggota'];?>" placeholder="ID Anggota"  readonly = "readonly" /></td>
                      </tr>
                        <tr>
                        <td>Tanggal Peminjaman :</td>
                        <td><input name="tanggal_peminjaman" type="date" class="form-control" id="tanggal_peminjaman" value="<?php echo $data['tanggal_peminjaman'];?>" placeholder="Tanggal Peminjaman"  readonly = "readonly" /></td>
                      </tr>
                      <tr>
                        <td>Jenis Pinjaman :</td>
                        <td><input name="jenis_pinjaman" type="text" class="form-control" id="jenis_pinjaman" value="<?php echo $data['jenis_pinjaman'];?>" placeholder="Jenis Pinjaman"  readonly = "readonly" /></td>
                      </tr>
					  <tr>
                        <td>Nominal :</td>
                        <td><input name="nominal" type="text" class="form-control" id="nominal" value="Rp. <?php echo number_format($data['nominal'], 2, ",", ".");?>" placeholder="Nominal"  readonly = "readonly" /></td>
                      </tr>
					  <tr>
                        <td>Biaya/Bulan :</td>
                        <td><input name="biaya_perbulan" type="text" class="form-control" id="biaya_perbulan" value="Rp. <?php echo number_format($data['biaya_perbulan'], 2, ",", ".");?>" placeholder="Biaya/Bulan"  readonly = "readonly" /></td>
                      </tr>
					  <tr>
                        <td>Status :</td>
                        <td><input name="status" type="text" class="form-control" id="status" value="<?php echo $data['status'];?>" placeholder="Status"  readonly = "readonly" /></td>
                      </tr>
					  <tr>
                        <td>Angsuran ke :</td>
                        <td><input name="status" type="text" class="form-control" id="status" value="<?php echo $data['angsuran_ke'];?>" placeholder="Status"  readonly = "readonly" /></td>
                      </tr>
					  <tr>
                        <td>Jangka Waktu :</td>
                        <td><input name="status" type="text" class="form-control" id="status" value="<?php echo $data['jangka_waktu'];?>" placeholder="Status"  readonly = "readonly" /></td>
                      </tr>
					   <tr>
                        <td>Sisa Angsur :</td>
                        <td><input name="status" type="text" class="form-control" id="status" value="<?php echo $sisa_angsur ;?>" placeholder="Status"  readonly = "readonly" /></td>
                      </tr>
                    </tbody>
                  </table>
                
                </div>
            </div>
                 <div class="panel-footer" style="margin-top: 50px;">
                        <a data-original-title="Broadcast Message"  href="hal_anggota_data_peminjaman.php" data-toggle="tooltip" class="btn btn-sm btn-primary"><i class="fa fa-back fa-2x" style="color: #FFFFFF;"></i>Kembali</a>
                 </div>
            
          </div>
        </div>
      </div>
    </div>
            </div><!-- .animated -->
        </div><!-- .content -->
            
			</div> <!-- .content -->

			<div class="clearfix"></div>

        

    </div><!-- /#right-panel -->


     <script src="assets/js/vendor/jquery-2.1.4.min.js"></script>
    <script src="assets/js/popper.min.js"></script>
    <script src="assets/js/plugins.js"></script>
    <script src="assets/js/main.js"></script>


    <script src="assets/js/lib/data-table/datatables.min.js"></script>
    <script src="assets/js/lib/data-table/dataTables.bootstrap.min.js"></script>
    <script src="assets/js/lib/data-table/dataTables.buttons.min.js"></script>
    <script src="assets/js/lib/data-table/buttons.bootstrap.min.js"></script>
    <script src="assets/js/lib/data-table/jszip.min.js"></script>
    <script src="assets/js/lib/data-table/pdfmake.min.js"></script>
    <script src="assets/js/lib/data-table/vfs_fonts.js"></script>
    <script src="assets/js/lib/data-table/buttons.html5.min.js"></script>
    <script src="assets/js/lib/data-table/buttons.print.min.js"></script>
    <script src="assets/js/lib/data-table/buttons.colVis.min.js"></script>
    <script src="assets/js/lib/data-table/datatables-init.js"></script>


    <script type="text/javascript">
        $(document).ready(function() {
          $('#bootstrap-data-table-export').DataTable();
      } );
  </script>




<div id="container">
  
 
  
</div>



</body>
</html>
