<!DOCTYPE html>
<html lang="en">
<?php 
    include "../proses/koneksi.php";

date_default_timezone_set('Asia/Jakarta'); 
ini_set('display_errors','Off');

header("Content-Type: application/force-download"); 
header("Cache-Control: no-cache, must-revalidate"); 
header("Expires: Sat, 26 Jul 2010 05:00:00 GMT"); 
header("content-disposition: attachment;filename=Laporan_Data_Angsuran_Bulanan".".xls");



?>
<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title></title>
	<link rel="shortcut icon" href="../asset/img/icon.png" />
	
</head>

<body>
                            <table border="1" style="border-collapse:collapse" align="center" cellpadding="6" cellspacing="6" width="1200">
								<tr>
									<TD ALIGN="CENTER" colspan="11"><FONT SIZE="4"><b>KOPERASI SIMPAN PINJAM KARYAWAN PT. HONDA PRECISION PARTS MANUFACTURING</b><BR>
                                        
                                    </TD>
                                </tr>
                                <tr>
									<td colspan="11" align="center"><h1 align="center">LAPORAN ANGSURAN BULANAN</h1></td><BR><BR>
								</tr>
								<tr></tr>
								<thead>
									<tr>
											<th>No</th>
                                            <th>ID Angsuran</th>
                                            <th>ID Anggota</th>
											<th>Nama</th>
											<th>Nominal Simpanan</th>
                                            <th>Jenis Pinjaman</th>
											<th>Nominal Pinjaman</th>
											<th>Biaya/Bulan</th>
                                            <th>Angsuran Ke</th>
											<th>Tanggal Angsuran</th>
											<th>Jumlah Angsuran</th>
								<!--		<th>jml_angsuran</th>
										<th>record</th>		-->
									</tr>
								</thead>
									
									<?php 
									$mulai_tgl	= $_POST['mulai_tgl'];
									$sampai_tgl 	= $_POST['sampai_tgl'];

									  $tampil = ("SELECT tb_angsuran.id_angsuran, tb_anggota.nama, tb_angsuran.nominal_simpanan, tb_angsuran.tanggal, tb_angsuran.angsuran_ke, tb_angsuran.biaya_perbulan, tb_angsuran.id_anggota, tb_angsuran.id_peminjaman, tb_pengajuan.id_pengajuan, tb_angsuran.id_anggota, tb_angsuran.angsuran_ke, tb_angsuran.jumlah_angsuran, tb_angsuran.nominal_peminjaman, tb_angsuran.jenis_pinjaman, tb_pengajuan.jangka_waktu FROM tb_anggota, tb_pengajuan, tb_angsuran, tb_peminjaman WHERE tb_anggota.id_anggota = tb_angsuran.id_anggota And tb_angsuran.id_anggota = tb_pengajuan.id_anggota AND tb_peminjaman.id_anggota = tb_anggota.id_anggota AND tb_peminjaman.id_peminjaman = tb_angsuran.id_peminjaman");
                                    $result = mysqli_query($connect, $tampil)or die(mysqli_error());
                                    $no =1;

									while($row = mysqli_fetch_array($result)){	
									?>
									<tr>
										<td><?php echo $no++;?></td>
										  <td><?php echo $row['id_angsuran']; ?></td>
                                            <td><?php echo $row['id_anggota']; ?></td>
                                            <td><?php echo $row['nama']; ?></td>
											<td><?php echo $row['nominal_simpanan']; ?></td>
                                            <td><?php echo $row['jenis_pinjaman']; ?></td>
											<td><?php echo $row['nominal_peminjaman']; ?></td>
											<td><?php echo $row['biaya_perbulan']; ?></td>
											<td><?php echo $row['angsuran_ke']; ?></td>
											<td><?php echo $row['tanggal']; ?></td>
											<td><?php echo $row['jumlah_angsuran']; ?></td>
									</tr>
									<?php }?>
							</table>
</body>

</html>
