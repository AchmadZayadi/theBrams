<!-- Left Panel --> 
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Ela Admin - HTML5 Admin Template</title>
    <meta name="description" content="Ela Admin - HTML5 Admin Template">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="apple-touch-icon" href="images/favicon.png">
    <link rel="shortcut icon" href="images/favicon.png">

    <link rel="stylesheet" href="assets/css/normalize.css">
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/font-awesome.min.css">
    <link rel="stylesheet" href="assets/css/themify-icons.css">
    <link rel="stylesheet" href="assets/css/pe-icon-7-filled.css">


    <link href="assets/weather/css/weather-icons.css" rel="stylesheet" />
    <link href="assets/calendar/fullcalendar.css" rel="stylesheet" />

    <link rel="stylesheet" href="assets/css/style.css">
    <link href="assets/css/charts/chartist.min.css" rel="stylesheet"> 
    <link href="assets/css/lib/vector-map/jqvmap.min.css" rel="stylesheet"> 


    <style>
    #weatherWidget .currentDesc {
        color: #ffffff!important;
    }
        .traffic-chart { 
            min-height: 335px; 
        }
        #flotPie1  {
            height: 150px;
        } 
        #flotPie1 td {
            padding:3px;
        }
        #flotPie1 table {
            top: 20px!important;
            right: -10px!important;
        }
        .chart-container {
            display: table;
            min-width: 270px ;
            text-align: left;
            padding-top: 10px;
            padding-bottom: 10px;
        }
        #flotLine5  {
             height: 105px;
        } 

        #flotBarChart {
            height: 150px;
        }
        #cellPaiChart{
            height: 160px;
        }

    </style>

</head> 

    <aside id="left-panel" class="left-panel">
        <nav class="navbar navbar-expand-sm navbar-default"> 
            <div id="main-menu" class="main-menu collapse navbar-collapse">
                <ul class="nav navbar-nav">
                    <li class="active">
                        <a href="hal_ketua.php"><i class="menu-icon fa fa-laptop"></i>Beranda</a>
                    </li>
                    <li class="menu-title">Menu Ketua Koperasi</li><!-- /.menu-title -->
					<li class="menu-item-has-children dropdown">
                        <a href="" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> <i class="menu-icon fa fa-cogs"></i>Menu Ketua Koperasi</a>
                        <ul class="sub-menu children dropdown-menu">
                            <li><i class="fa fa-id-badge"></i><a href="hal_ketua_data_admin.php">Data Admin</a></li>
                            <li><i class="fa fa-id-card-o"></i><a href="hal_ketua_data_anggota.php">Data Anggota</a></li>
                        </ul>
                    </li>
                    
                    <li class="menu-title">Menu Simpanan</li><!-- /.menu-title -->

                    <li class="">
                        <a href="hal_ketua_data_simpanan.php" aria-expanded="false"> <i class="menu-icon fa fa-tasks"></i>Data Simpanan</a>
                    </li>
										
					<li class="menu-title">Menu Peminjaman</li><!-- /.menu-title -->
					<li class="">
                        <a href="hal_ketua_download_laporan.php" aria-expanded="false"> <i class="menu-icon fa fa-tasks"></i>Data Peminjaman</a>
                    </li>
					<li class="menu-title">Menu Pengumuman</li><!-- /.menu-title -->
					<li class="">
                        <a href="hal_ketua_data_pengumuman.php" aria-expanded="false"> <i class="menu-icon fa fa-tasks"></i>Data Pengumuman</a>
                    </li>
                </ul>
            </div><!-- /.navbar-collapse -->
        </nav>
    </aside><!-- /#left-panel --> 
    <!-- Left Panel -->