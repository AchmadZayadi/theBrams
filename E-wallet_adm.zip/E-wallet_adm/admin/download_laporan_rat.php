<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title></title>
    <meta name="description" content="Ela Admin - HTML5 Admin Template">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="apple-touch-icon" href="images/fav.png">
    <link rel="shortcut icon" href="images/fav.png">

    <link rel="stylesheet" href="assets/css/normalize.css">
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/font-awesome.min.css">
    <link rel="stylesheet" href="assets/css/themify-icons.css">
    <link rel="stylesheet" href="assets/css/pe-icon-7-filled.css">


    <link href="assets/weather/css/weather-icons.css" rel="stylesheet" />
    <link href="assets/calendar/fullcalendar.css" rel="stylesheet" />

    <link rel="stylesheet" href="assets/css/style.css">
    <link href="assets/css/charts/chartist.min.css" rel="stylesheet"> 
    <link href="assets/css/lib/vector-map/jqvmap.min.css" rel="stylesheet"> 


    <style>
    #weatherWidget .currentDesc {
        color: #ffffff!important;
    }
        .traffic-chart { 
            min-height: 335px; 
        }
        #flotPie1  {
            height: 150px;
        } 
        #flotPie1 td {
            padding:3px;
        }
        #flotPie1 table {
            top: 20px!important;
            right: -10px!important;
        }
        .chart-container {
            display: table;
            min-width: 270px ;
            text-align: left;
            padding-top: 10px;
            padding-bottom: 10px;
        }
        #flotLine5  {
             height: 105px;
        } 

        #flotBarChart {
            height: 150px;
        }
        #cellPaiChart{
            height: 160px;
        }

    </style>

</head>						
										<TABLE WIDTH="100%">
											<TR>
											<BR><TD ALIGN="CENTER" WIDTH="20%"><img style="width:150px; margin-top: 10px;" src="images/k.png" alt="..." class="img-circle"></TD><BR>
											<BR><TD ALIGN="CENTER" WIDTH="180%"><FONT SIZE="6"><b>LAPORAN RAPAT ANGGOTA TAHUNAN</b><BR>
													<b>KOPERASI KARYAWAN</b><BR>
													<b>PT. HONDA PRECISION PARTS MANUFACTURING</b><BR>	
													
												</TD>
                                        </TABLE><BR><BR><BR>
                                                <hr>
												<p hidden id="keterangan1">•	Jumlah anggota tahun 2013 adalah sebagai berikut :</p>
                                                <div class="table-responsive">
                                                    <?php
													 include "../proses/koneksi.php";
                                                    $tampil = ("SELECT tb_angsuran.id_angsuran, tb_anggota.nama, tb_angsuran.nominal_simpanan, tb_angsuran.tanggal, tb_angsuran.angsuran_ke, tb_angsuran.id_anggota, tb_angsuran.id_peminjaman, tb_pengajuan.id_pengajuan, tb_angsuran.id_anggota, tb_angsuran.angsuran_ke, tb_angsuran.jumlah_angsuran, tb_angsuran.nominal_peminjaman, tb_angsuran.jenis_pinjaman, tb_pengajuan.jangka_waktu FROM tb_anggota, tb_pengajuan, tb_angsuran, tb_peminjaman WHERE tb_anggota.id_anggota = tb_angsuran.id_anggota And tb_angsuran.id_anggota = tb_pengajuan.id_anggota AND tb_peminjaman.id_anggota = tb_anggota.id_anggota AND tb_peminjaman.id_peminjaman = tb_angsuran.id_peminjaman");
                                                    $result = mysqli_query($connect, $tampil)or die(mysqli_error());
                                                   ?>
													<table class="table table-condensed ">
                                                        <?php while ($data = mysqli_fetch_array($result)) {
														?>
														
                                                        </table>
                                                         <div class="text-Left">
														
														 <?php
														 
														 
                                    $tampil = ("SELECT COUNT(id_anggota) as jumlah, tanggal_registrasi FROM tb_anggota WHERE tanggal_registrasi LIKE '2018%'
");
                                    $result = mysqli_query($connect, $tampil)or die(mysqli_error());
									 $data = mysqli_fetch_array($result); 
									 
									 $tampil3 = ("SELECT COUNT(id_anggota) as jumlah, tanggal_registrasi FROM tb_anggota WHERE tanggal_registrasi LIKE '2019%'
");
                                    $result3 = mysqli_query($connect, $tampil3)or die(mysqli_error());
									 $data3 = mysqli_fetch_array($result3);
									 
									  $tampil2 = ("SELECT COUNT(id_anggota) as total FROM tb_anggota");
                                    $result2 = mysqli_query($connect, $tampil2)or die(mysqli_error());
									 $data2 = mysqli_fetch_array($result2);
                                    ?>
									<center><h3>Data Anggota</h3></center><br/>
									<p>Berikut adalah tabel rincian data anggota Koperasi Simpan Pinjam PT. Honda Precision Parts Manufacturing per periode:</p>
                                <table  class="table table-striped table-bordered">
                                    <thead>
									
                                        <tr>
											<th>Periode</th>
											<th>Anggota Masuk</th>
											<th></th>
											<th>Jumlah Anggota</th>
											<th></th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
											<td>2018</td>
											<td><?php echo $data['jumlah']; ?><td>
											<td><?php echo $data['jumlah']; ?><td>
                                        </tr>
										<tr>
											<td>2019</td>
											<td><?php echo $data3['jumlah']; ?><td>
											<td><?php echo $data2['total']; ?><td>
                                        </tr>
                                    </tbody>
                                </table>
								<p>Catatan:</p>
								<p>1. Jumlah Anggota yang masuk  di tahun 2018 sebanyak <?php echo $data['jumlah']; ?> anggota & jumlah anggota per 2018 sebanyak <?php echo $data['jumlah']; ?> Anggota.
								</br>2. Jumlah Anggota yang masuk  di tahun 2019 sebanyak <?php echo $data3['jumlah']; ?> anggota & jumlah anggota per 2019 sebanyak <?php echo $data2['total']; ?> Anggota.
								</p>
								<br/>
								<br/>
								<br/>
								<hr>
								
								 <?php
														 
														 
                                    $tampil = ("SELECT COUNT(id_anggota) as total_anggota, SUM(nominal) as jumlah_nominal FROM tb_simpanan WHERE jenis_simpanan = 'POKOK' AND tanggal LIKE '2018%'
");
                                    $result = mysqli_query($connect, $tampil)or die(mysqli_error());
									 $data = mysqli_fetch_array($result); 
									 
									 $tampil3 = ("SELECT COUNT(id_anggota) as total_anggota, SUM(nominal) as jumlah_nominal FROM tb_simpanan WHERE jenis_simpanan = 'POKOK' AND tanggal LIKE '2019%'
");
                                    $result3 = mysqli_query($connect, $tampil3)or die(mysqli_error());
									 $data3 = mysqli_fetch_array($result3);
									 
									  $tampil2 = ("SELECT COUNT(id_anggota) as total FROM tb_simpanan");
                                    $result2 = mysqli_query($connect, $tampil2)or die(mysqli_error());
									 $data2 = mysqli_fetch_array($result2);
                                    ?>
									<center><h3>Data Simpanan Pokok</h3></center><br/>
									<p>Berikut adalah tabel rincian data simpanan pokok Koperasi Simpan Pinjam PT. Honda Precision Parts Manufacturing per periode: </p>
                                <table  class="table table-striped table-bordered">
                                    <thead>
									
                                        <tr>
											<th>Periode</th>
											<th>Total Anggota</th>
											<th></th>
											<th>Jumlah</th>
											<th></th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
											<td>2018</td>
											<td><?php echo $data['total_anggota']; ?><td>
											<td>Rp. <?php echo number_format($data['jumlah_nominal'], 2, ",", "."); ?><td>
                                        </tr>
										<tr>
											<td>2019</td>
											<td><?php echo $data3['total_anggota']; ?><td>
											<td>Rp. <?php echo number_format($data3['jumlah_nominal'], 2, ",", "."); ?><td>
                                        </tr>
                                    </tbody>
                                </table>
								<p>Catatan:</p>
								<p>1. Total anggota yang bergabung dengan koperasi di tahun 2018 sebanyak <?php echo $data['total_anggota']; ?> anggota & total simpanan pokok per 2018 sebesar Rp. <?php echo number_format($data['jumlah_nominal'], 2, ",", "."); ?>.
								</br>2. Total anggota yang bergabung dengan koperasi di tahun di tahun 2019 sebanyak <?php echo $data3['total_anggota']; ?> anggota & total simpanan pokok per 2019 sebesar Rp. <?php echo number_format($data3['jumlah_nominal'], 2, ",", "."); ?>.
								</p>
								<br/>
								<br/>
								<br/>
								<hr>
								
								<?php
														 
														 
                                    $tampil = ("SELECT COUNT(id_anggota) as total_anggota, SUM(nominal) as jumlah_nominal FROM tb_simpanan WHERE jenis_simpanan = 'WAJIB' AND tanggal LIKE '2018%'
");
                                    $result = mysqli_query($connect, $tampil)or die(mysqli_error());
									 $data = mysqli_fetch_array($result); 
									 
									 $tampil3 = ("SELECT COUNT(id_anggota) as total_anggota, SUM(nominal) as jumlah_nominal FROM tb_simpanan WHERE jenis_simpanan = 'WAJIB' AND tanggal LIKE '2019%'
");
                                    $result3 = mysqli_query($connect, $tampil3)or die(mysqli_error());
									 $data3 = mysqli_fetch_array($result3);
									 
									  $tampil2 = ("SELECT COUNT(id_anggota) as total2 FROM tb_simpanan");
                                    $result2 = mysqli_query($connect, $tampil2)or die(mysqli_error());
									 $data2 = mysqli_fetch_array($result2);
									 $tampil31 = ("select SUM(nominal_simpanan) AS total1 from tb_angsuran where id_anggota");
                                    $result31 = mysqli_query($connect, $tampil31)or die(mysqli_error());
									$row31 = mysqli_fetch_array($result31);
									$total = $data2['total2'] + $row31['total1'];
                                    ?>
									<center><h3>Data Simpanan Wajib</h3></center><br/>
									<p>Berikut adalah tabel rincian data simpanan wajib Koperasi Simpan Pinjam PT. Honda Precision Parts Manufacturing per periode:</p>
                                <table  class="table table-striped table-bordered">
                                    <thead>
									
                                        <tr>
											<th>Periode</th>
											<th>Total Anggota</th>
											<th></th>
											<th>Jumlah</th>
											<th></th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
											<td>2018</td>
											<td><?php echo $data['total_anggota']; ?><td>
											<td>Rp. <?php echo number_format($data['jumlah_nominal'], 2, ",", "."); ?><td>
                                        </tr>
										<tr>
											<td>2019</td>
											<td><?php echo $data3['total_anggota']; ?><td>
											<td>Rp. <?php echo number_format($total, 2, ",", "."); ?><td>
                                        </tr>
                                    </tbody>
                                </table>
								<p>Catatan:</p>
								<p>1. Total anggota yang bergabung dengan koperasi di tahun 2018 sebanyak <?php echo $data['total_anggota']; ?> anggota & total angsuran simpanan wajib anggota per 2018 sebesar Rp. <?php echo number_format($data['jumlah_nominal'], 2, ",", "."); ?>.
								</br>2. Total anggota yang bergabung dengan koperasi di tahun di tahun 2019 sebanyak <?php echo $data3['total_anggota']; ?> anggota & total angsuran simpanan wajib anggota per 2019 sebesar Rp. <?php echo number_format($total, 2, ",", "."); ?>.
								</p>
								<br/>
								<br/>
								<br/>
								<hr>
								
								<?php
														 
														 
                                    $tampil = ("SELECT COUNT(id_anggota) as total_anggota, SUM(nominal) as jumlah_nominal FROM tb_simpanan WHERE jenis_simpanan = 'Sukarela' AND tanggal LIKE '2018%'
");
                                    $result = mysqli_query($connect, $tampil)or die(mysqli_error());
									 $data = mysqli_fetch_array($result); 
									 
									 $tampil3 = ("SELECT COUNT(id_anggota) as total_anggota, SUM(nominal) as jumlah_nominal FROM tb_simpanan WHERE jenis_simpanan = 'Sukarela' AND tanggal LIKE '2019%'
");
                                    $result3 = mysqli_query($connect, $tampil3)or die(mysqli_error());
									 $data3 = mysqli_fetch_array($result3);
									 
									  $tampil2 = ("SELECT COUNT(id_anggota) as total FROM tb_simpanan");
                                    $result2 = mysqli_query($connect, $tampil2)or die(mysqli_error());
									 $data2 = mysqli_fetch_array($result2);
                                    ?>
									<center><h3>Data Simpanan Sukarela</h3></center><br/>
									<p>Berikut adalah tabel rincian data simpanan sukarela Koperasi Simpan Pinjam PT. Honda Precision Parts Manufacturing per periode: </p>
                                <table  class="table table-striped table-bordered">
                                    <thead>
									
                                        <tr>
											<th>Periode</th>
											<th>Total Anggota</th>
											<th></th>
											<th>Jumlah</th>
											<th></th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
											<td>2018</td>
											<td><?php echo $data['total_anggota']; ?><td>
											<td>Rp. <?php echo number_format($data['jumlah_nominal'], 2, ",", "."); ?><td>
                                        </tr>
										<tr>
											<td>2019</td>
											<td><?php echo $data3['total_anggota']; ?><td>
											<td>Rp. <?php echo number_format($data3['jumlah_nominal'], 2, ",", "."); ?><td>
                                        </tr>
                                    </tbody>
                                </table>
								<p>Catatan:</p>
								<p>1. Total anggota yang melakukan simpanan sukarela di tahun 2018 sebanyak <?php echo $data['total_anggota']; ?> anggota & total angsuran simpanan sukarela anggota per 2018 sebesar Rp. <?php echo number_format($data['jumlah_nominal'], 2, ",", "."); ?>.
								</br>2. Total anggota yang melakukan simpanan sukarela di tahun di tahun 2019 sebanyak <?php echo $data3['total_anggota']; ?> anggota & total angsuran simpanan sukarela anggota per 2019 sebesar Rp. <?php echo number_format($data3['jumlah_nominal'], 2, ",", "."); ?>.
								</p>
								<br/>
								<br/>
								<br/>
								<hr>
								
									 <?php
														 
														 
                                    $tampil = ("SELECT COUNT(id_anggota) as total_anggota, SUM(nominal) as jumlah_nominal FROM tb_peminjaman WHERE jenis_pinjaman = 'EMERGENCY' AND tanggal_peminjaman LIKE '2018%'
");
                                    $result = mysqli_query($connect, $tampil)or die(mysqli_error());
									 $data = mysqli_fetch_array($result); 
									 
									 $tampil3 = ("SELECT COUNT(id_anggota) as total_anggota, SUM(nominal) as jumlah_nominal FROM tb_peminjaman WHERE jenis_pinjaman = 'EMERGENCY' AND tanggal_peminjaman LIKE '2019%'
");
                                    $result3 = mysqli_query($connect, $tampil3)or die(mysqli_error());
									 $data3 = mysqli_fetch_array($result3);
									 
									  $tampil2 = ("SELECT COUNT(id_anggota) as total FROM tb_peminjaman");
                                    $result2 = mysqli_query($connect, $tampil2)or die(mysqli_error());
									 $data2 = mysqli_fetch_array($result2);
                                    ?>
									<center><h3>Data Peminjaman Emergency</h3></center><br/>
									<p>Berikut adalah tabel rincian data peminjaman emergency Koperasi Simpan Pinjam PT. Honda Precision Parts Manufacturing per periode: </p>
                                <table  class="table table-striped table-bordered">
                                    <thead>
									
                                        <tr>
											<th>Periode</th>
											<th>Total Anggota</th>
											<th></th>
											<th>Jumlah</th>
											<th></th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
											<td>2018</td>
											<td><?php echo $data['total_anggota']; ?><td>
											<td>Rp. <?php echo number_format($data['jumlah_nominal'], 2, ",", "."); ?><td>
                                        </tr>
										<tr>
											<td>2019</td>
											<td><?php echo $data3['total_anggota']; ?><td>
											<td>Rp. <?php echo number_format($data3['jumlah_nominal'], 2, ",", "."); ?><td>
                                        </tr>
                                    </tbody>
                                </table>
								<p>Catatan:</p>
								<p>1. Total Anggota yang meminjam pinjaman emergency di tahun 2018 sebanyak <?php echo $data['total_anggota']; ?> anggota & total pinjaman emergency per 2018 sebesar Rp. <?php echo number_format($data['jumlah_nominal'], 2, ",", "."); ?>.
								</br>2. Total Anggota yang meminjam pinjaman emergency di tahun 2019 sebanyak <?php echo $data3['total_anggota']; ?> anggota & total pinjaman emergency per 2019 sebesar Rp. <?php echo number_format($data3['jumlah_nominal'], 2, ",", "."); ?>.
								</p>
								<br/>
								<br/>
								<br/>
								<hr>
									 <?php
														
														 
                                    $tampil = ("SELECT COUNT(id_anggota) as total_anggota, SUM(nominal) as jumlah_nominal FROM tb_peminjaman WHERE jenis_pinjaman = 'KJP' AND tanggal_peminjaman LIKE '2018%'
");
                                    $result = mysqli_query($connect, $tampil)or die(mysqli_error());
									 $data = mysqli_fetch_array($result); 
									 
									 $tampil3 = ("SELECT COUNT(id_anggota) as total_anggota, SUM(nominal) as jumlah_nominal FROM tb_peminjaman WHERE jenis_pinjaman = 'KJP' AND tanggal_peminjaman LIKE '2019%'
");
                                    $result3 = mysqli_query($connect, $tampil3)or die(mysqli_error());
									 $data3 = mysqli_fetch_array($result3);
									 
									  $tampil2 = ("SELECT COUNT(id_anggota) as total FROM tb_peminjaman");
                                    $result2 = mysqli_query($connect, $tampil2)or die(mysqli_error());
									 $data2 = mysqli_fetch_array($result2);
                                    ?>
									<center><h3>Data Peminjaman KJP</h3></center><br/>
									<p>Berikut adalah tabel rincian data peminjaman KJP (Kredit Jangka Pendek) Koperasi Simpan Pinjam PT. Honda Precision Parts Manufacturing per periode: </p>
                                <table  class="table table-striped table-bordered">
                                    <thead>
									
                                        <tr>
											<th>Periode</th>
											<th>Total Anggota</th>
											<th></th>
											<th>Jumlah</th>
											<th></th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
											<td>2018</td>
											<td><?php echo $data['total_anggota']; ?><td>
											<td>Rp. <?php echo number_format($data['jumlah_nominal'], 2, ",", "."); ?><td>
                                        </tr>
										<tr>
											<td>2019</td>
											<td><?php echo $data3['total_anggota']; ?><td>
											<td>Rp. <?php echo number_format($data3['jumlah_nominal'], 2, ",", "."); ?><td>
                                        </tr>
                                    </tbody>
                                </table>
								<p>Catatan:</p>
								<p>1. Total Anggota yang meminjam pinjaman KJP di tahun 2018 sebanyak <?php echo $data['total_anggota']; ?> anggota & total pinjaman KJP per 2018 sebesar Rp. <?php echo number_format($data['jumlah_nominal'], 2, ",", "."); ?>.
								</br>2. Total Anggota yang meminjam pinjaman KJP di tahun 2019 sebanyak <?php echo $data3['total_anggota']; ?> anggota & total pinjaman KJP per 2019 sebesar Rp. <?php echo number_format($data3['jumlah_nominal'], 2, ",", "."); ?>.
								</p>
								<br/>
								<br/>
								<br/>
								<hr>
									 <?php
														
														 
                                    $tampil = ("SELECT COUNT(id_anggota) as total_anggota, SUM(nominal) as jumlah_nominal FROM tb_peminjaman WHERE jenis_pinjaman = 'PINSUS ' AND tanggal_peminjaman LIKE '2018%'
");
                                    $result = mysqli_query($connect, $tampil)or die(mysqli_error());
									 $data = mysqli_fetch_array($result); 
									 
									 $tampil3 = ("SELECT COUNT(id_anggota) as total_anggota, SUM(nominal) as jumlah_nominal FROM tb_peminjaman WHERE jenis_pinjaman = 'PINSUS ' AND tanggal_peminjaman LIKE '2019%'
");
                                    $result3 = mysqli_query($connect, $tampil3)or die(mysqli_error());
									 $data3 = mysqli_fetch_array($result3);
									 
									  $tampil2 = ("SELECT COUNT(id_anggota) as total FROM tb_peminjaman");
                                    $result2 = mysqli_query($connect, $tampil2)or die(mysqli_error());
									 $data2 = mysqli_fetch_array($result2);
                                    ?>
									<center><h3>Data Peminjaman PINSUS</h3></center><br/>
									<p>Berikut adalah tabel rincian data peminjaman PINSUS (Pinjaman Khusus) Koperasi Simpan Pinjam PT. Honda Precision Parts Manufacturing per periode:</p>
                                <table  class="table table-striped table-bordered">
                                    <thead>
									
                                        <tr>
											<th>Periode</th>
											<th>Total Anggota</th>
											<th></th>
											<th>Jumlah</th>
											<th></th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
											<td>2018</td>
											<td><?php echo $data['total_anggota']; ?><td>
											<td>Rp. <?php echo number_format($data['jumlah_nominal'], 2, ",", "."); ?><td>
                                        </tr>
										<tr>
											<td>2019</td>
											<td><?php echo $data3['total_anggota']; ?><td>
											<td>Rp. <?php echo number_format($data3['jumlah_nominal'], 2, ",", "."); ?><td>
                                        </tr>
                                    </tbody>
                                </table>
								<p>Catatan:</p>
								<p>1. Total Anggota yang meminjam pinjaman PINSUS di tahun 2018 sebanyak <?php echo $data['total_anggota']; ?> anggota & total pinjaman PINSUS per 2018 sebesar Rp. <?php echo number_format($data['jumlah_nominal'], 2, ",", "."); ?>.
								</br>2. Total Anggota yang meminjam pinjaman PINSUS di tahun 2019 sebanyak <?php echo $data3['total_anggota']; ?> anggota & total pinjaman PINSUS per 2019 sebesar Rp. <?php echo number_format($data3['jumlah_nominal'], 2, ",", "."); ?>.
								</p>
								<br/>
								<br/>
								<br/>
								<hr>
								
								<?php
														
														 
                                    $tampil = ("SELECT COUNT(id_anggota) as total_anggota, SUM(nominal) as jumlah_nominal FROM tb_peminjaman WHERE jenis_pinjaman = 'SYARIAH' AND tanggal_peminjaman LIKE '2018%'
");
                                    $result = mysqli_query($connect, $tampil)or die(mysqli_error());
									 $data = mysqli_fetch_array($result); 
									 
									 $tampil3 = ("SELECT COUNT(id_anggota) as total_anggota, SUM(nominal) as jumlah_nominal FROM tb_peminjaman WHERE jenis_pinjaman = 'SYARIAH' AND tanggal_peminjaman LIKE '2019%'
");
                                    $result3 = mysqli_query($connect, $tampil3)or die(mysqli_error());
									 $data3 = mysqli_fetch_array($result3);
									 
									  $tampil2 = ("SELECT COUNT(id_anggota) as total FROM tb_peminjaman");
                                    $result2 = mysqli_query($connect, $tampil2)or die(mysqli_error());
									 $data2 = mysqli_fetch_array($result2);
                                    ?>
									<center><h3>Data Peminjaman SYARIAH</h3></center><br/>
									<p>Berikut adalah tabel rincian data peminjaman SYARIAH Koperasi Simpan Pinjam PT. Honda Precision Parts Manufacturing per periode:</p>
                                <table  class="table table-striped table-bordered">
                                    <thead>
									
                                        <tr>
											<th>Periode</th>
											<th>Total Anggota</th>
											<th></th>
											<th>Jumlah</th>
											<th></th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
											<td>2018</td>
											<td><?php echo $data['total_anggota']; ?><td>
											<td>Rp. <?php echo number_format($data['jumlah_nominal'], 2, ",", "."); ?><td>
                                        </tr>
										<tr>
											<td>2019</td>
											<td><?php echo $data3['total_anggota']; ?><td>
											<td>Rp. <?php echo number_format($data3['jumlah_nominal'], 2, ",", "."); ?><td>
                                        </tr>
                                    </tbody>
                                </table>
								<p>Catatan:</p>
								<p>1. Total Anggota yang meminjam pinjaman SYARIAH di tahun 2018 sebanyak <?php echo $data['total_anggota']; ?> anggota & total pinjaman SYARIAH per 2018 sebesar Rp. <?php echo number_format($data['jumlah_nominal'], 2, ",", "."); ?>.
								</br>2. Total Anggota yang meminjam pinjaman SYARIAH di tahun 2019 sebanyak <?php echo $data3['total_anggota']; ?> anggota & total pinjaman SYARIAH per 2019 sebesar Rp. <?php echo number_format($data3['jumlah_nominal'], 2, ",", "."); ?>.
								</p>
								<br/>
								<br/>
								<br/>
								<hr>
								
								<?php
								
								 $tampil2018 = ("SELECT COUNT(id_anggota) as total_anggota, SUM(nominal) as jumlah_nominal FROM tb_peminjaman WHERE tanggal_peminjaman LIKE '2018%'
");
                                    $result2018 = mysqli_query($connect, $tampil2018)or die(mysqli_error());
									 $data2018 = mysqli_fetch_array($result2018); 
									 
									  $tampil2019 = ("SELECT COUNT(id_anggota) as total_anggota, SUM(nominal) as jumlah_nominal FROM tb_peminjaman
");
                                    $result2019 = mysqli_query($connect, $tampil2019)or die(mysqli_error());
									 $data2019 = mysqli_fetch_array($result2019); 
								
									$tampil2 = ("SELECT sum(uang_masuk) as keuntungan, tabungan_koperasi FROM tb_audit where tanggal_transaksi LIKE '2018%'");
                                    $result2 = mysqli_query($connect, $tampil2)or die(mysqli_error());
									 $data2 = mysqli_fetch_array($result2);
									 
									  $keuntungan = $data2['keuntungan'];
										
									 
									 $tampil21 = ("SELECT sum(uang_masuk) as keuntungan FROM tb_audit where tanggal_transaksi LIKE '2019%'");
                                    $result12 = mysqli_query($connect, $tampil21)or die(mysqli_error());
									 $data112 = mysqli_fetch_array($result12); 
									 
									 
									 $tampil22 = ("SELECT tabungan_koperasi as total_tabungan FROM tb_audit ORDER BY id_audit DESC 
LIMIT 1");
                                    $result122 = mysqli_query($connect, $tampil22)or die(mysqli_error());
									 $data1122 = mysqli_fetch_array($result122);
									 
										
										 $keuntungan2 = $data112['keuntungan'];
                                    ?>
									<center><h3>Data Tabungan Koperasi</h3></center><br/>
									<p>Berikut adalah tabel rincian data tabungan Koperasi Simpan Pinjam PT. Honda Precision Parts Manufacturing per periode:</p>
                                <table  class="table table-striped table-bordered">
                                    <thead>
									
                                        <tr>
											<th>Periode</th>
											<th>Uang Masuk</th>
											<th></th>
											<th>Tabungan Koperasi</th>
											<th></th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
											<td>2018</td>
											<td>Rp. <?php echo number_format($keuntungan, 2, ",", "."); ?><td>
											<td>Rp. <?php echo number_format($data2['tabungan_koperasi'], 2, ",", "."); ?><td>
                                        </tr>
										<tr>
											<td>2019</td>
											<td>Rp. <?php echo number_format($keuntungan2, 2, ",", "."); ?><td>
											<td>Rp. <?php echo number_format($data1122['total_tabungan'], 2, ",", "."); ?><td>
                                        </tr>
                                    </tbody>
                                </table>
								<p>Catatan:</p>
								<p>1. Total uang masuk ke koperasi di tahun 2018 sebesar <?php echo number_format($keuntungan, 2, ",", "."); ?> rupiah & total tabungan koperasi per 2018 sebesar Rp. <?php echo number_format($data2['tabungan_koperasi'], 2, ",", "."); ?> rupiah.
								<br/>2. Total uang masuk ke koperasi di tahun 2019 sebesar <?php echo number_format($keuntungan2, 2, ",", "."); ?> rupiah & total tabungan koperasi per 2019 sebesar Rp. <?php echo number_format($data1122['total_tabungan'], 2, ",", "."); ?> rupiah.</p>
								<br/>
								
								<hr>
								</div>
														
                                                    </div>
                                                    

                                                    <?php
                                                }
                                                ?>
                                                <br />
                                                <br />
                                                <div class="text-right">
                                                    <a href="#" onclick="  window.print(); return true"  id="tombol" class="btn btn-sm btn-primary">Print<i class="fa fa-print"></i></a>
                                                    <a href="hal_admin.php" id="tombol" class="btn btn-sm btn-primary">Kembali<i class="fa fa-backward"></i></a>
                                                </div>
                                                </div> 
                      </div><!-- /#right-panel -->


     <script src="assets/js/vendor/jquery-2.1.4.min.js"></script>
    <script src="assets/js/popper.min.js"></script>
    <script src="assets/js/plugins.js"></script>
    <script src="assets/js/main.js"></script>


    <script src="assets/js/lib/data-table/datatables.min.js"></script>
    <script src="assets/js/lib/data-table/dataTables.bootstrap.min.js"></script>
    <script src="assets/js/lib/data-table/dataTables.buttons.min.js"></script>
    <script src="assets/js/lib/data-table/buttons.bootstrap.min.js"></script>
    <script src="assets/js/lib/data-table/jszip.min.js"></script>
    <script src="assets/js/lib/data-table/pdfmake.min.js"></script>
    <script src="assets/js/lib/data-table/vfs_fonts.js"></script>
    <script src="assets/js/lib/data-table/buttons.html5.min.js"></script>
    <script src="assets/js/lib/data-table/buttons.print.min.js"></script>
    <script src="assets/js/lib/data-table/buttons.colVis.min.js"></script>
    <script src="assets/js/lib/data-table/datatables-init.js"></script>

<style>
                                                    @media print{
                                                        #tombol{
                                                            display:none;
                                                        }
														 #headera{
                                                            display:none;
                                                        }
														 #samping{
                                                            display:none;
                                                        }
														#keterangan1{
                                                            display:block;
                                                        }
													
                                                    }
                                                </style>
    <script type="text/javascript">
        $(document).ready(function() {
          $('#bootstrap-data-table-export').DataTable();
      } );
  </script>