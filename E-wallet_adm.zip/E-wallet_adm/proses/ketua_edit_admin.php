<?php

include "koneksi.php";
$id_admin = $_POST['id_admin'];
$nama = $_POST['nama'];
$jabatan = $_POST['jabatan'];

$query = ("UPDATE tb_admin SET id_admin='$id_admin', "
        . "nama='$nama', "
        . "jabatan='$jabatan'
 WHERE id_admin ='$id_admin'");
$result = mysqli_query($connect, $query)or die(mysqli_error());
if ($query) {
    echo "<script>alert('Data Admin Berhasil diubah!'); window.location = '../hal_ketua_data_admin.php'</script>";
} else {
    echo "<script>alert('Data Admin Gagal diubah!'); window.location = 'ketua_edit_admin.php?hal=edit&kd=$id</script>";
}
?>