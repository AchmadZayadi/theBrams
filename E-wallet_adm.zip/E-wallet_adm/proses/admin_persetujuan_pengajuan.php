<?php
include "koneksi.php";

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'vendor/phpmailer/phpmailer/src/Exception.php';
require 'vendor/phpmailer/phpmailer/src/PHPMailer.php';
require 'vendor/phpmailer/phpmailer/src/SMTP.php';
require 'vendor/autoload.php';

$res  = mysqli_query($connect,"SELECT * FROM tb_anggota WHERE id_anggota='$_GET[hal]'") or die(mysqli_error($connect));


if($res && mysqli_num_rows($res)>0)
{
    $data = mysqli_fetch_assoc($res);
    $userEmail = $data['email']; // now this is your email id variable for user's email address.
  	$nama = $data['nama'];	


    $mail = new PHPMailer(true);
try {
    $subject = "Pengajuan Pinjaman Anda Disetujui";
    $content = '<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta http-equiv="content-type" content="text/html; charset=utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0;">
    <meta name="format-detection" content="telephone=no"/>

 

    <style>
/* Reset styles */ 
body { margin: 0; padding: 0; min-width: 100%; width: 100% !important; height: 100% !important;}
body, table, td, div, p, a { -webkit-font-smoothing: antialiased; text-size-adjust: 100%; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: 100%; line-height: 100%; }
table, td { mso-table-lspace: 0pt; mso-table-rspace: 0pt; border-collapse: collapse !important; border-spacing: 0; }
img { border: 0; line-height: 100%; outline: none; text-decoration: none; -ms-interpolation-mode: bicubic; }
#outlook a { padding: 0; }
.ReadMsgBody { width: 100%; } .ExternalClass { width: 100%; }
.ExternalClass, .ExternalClass p, .ExternalClass span, .ExternalClass font, .ExternalClass td, .ExternalClass div { line-height: 100%; }

/* Rounded corners for advanced mail clients only */ 
@media all and (min-width: 560px) {
    .container { border-radius: 8px; -webkit-border-radius: 8px; -moz-border-radius: 8px; -khtml-border-radius: 8px; }
}

/* Set color for auto links (addresses, dates, etc.) */ 
a, a:hover {
    color: #FFFFFF;
}
.footer a, .footer a:hover {
    color: #828999;
}

    </style>

    <!-- MESSAGE SUBJECT -->
    <title>Responsive HTML email templates</title>

</head>

<!-- BODY -->
<!-- Set message background color (twice) and text color (twice) -->
<body topmargin="0" rightmargin="0" bottommargin="0" leftmargin="0" marginwidth="0" marginheight="0" width="100%" style="border-collapse: collapse; border-spacing: 0; margin: 0; padding: 0; width: 100%; height: 100%; -webkit-font-smoothing: antialiased; text-size-adjust: 100%; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: 100%; line-height: 100%;
    background-color: #2D3445;
    color: #FFFFFF;"
    bgcolor="#2D3445"
    text="#FFFFFF">

<!-- SECTION / BACKGROUND -->
<!-- Set message background color one again -->
<table width="100%" align="center" border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse; border-spacing: 0; margin: 0; padding: 0; width: 100%;" class="background"><tr><td align="center" valign="top" style="border-collapse: collapse; border-spacing: 0; margin: 0; padding: 0;"
    bgcolor="#2D3445">

<!-- WRAPPER -->
<!-- Set wrapper width (twice) -->
<table border="0" cellpadding="0" cellspacing="0" align="center"
    width="500" style="border-collapse: collapse; border-spacing: 0; padding: 0; width: inherit;
    max-width: 500px;" class="wrapper">

    <tr>
        <td align="center" valign="top" style="border-collapse: collapse; border-spacing: 0; margin: 0; padding: 0; padding-left: 6.25%; padding-right: 6.25%; width: 87.5%;
            padding-top: 20px;
            padding-bottom: 20px;">

            <!-- PREHEADER -->
            <!-- Set text color to background color -->
            <div style="display: none; visibility: hidden; overflow: hidden; opacity: 0; font-size: 1px; line-height: 1px; height: 0; max-height: 0; max-width: 0;
                color: #2D3445;" class="preheader">
                Halo selamat pengajuan pinjaman Anda telah disetujui.</div>

            
        </td>
    </tr>

    <!-- HERO IMAGE -->
    <!-- Image text color should be opposite to background color. Set your url, image src, alt and title. Alt text should fit the image size. Real image size should be x2 (wrapper x2). Do not set height for flexible images (including "auto"). URL format: http://domain.com/?utm_source={{Campaign-Source}}&utm_medium=email&utm_content={{Ìmage-Name}}&utm_campaign={{Campaign-Name}} -->
    <tr>
        <td align="center" valign="top" style="border-collapse: collapse; border-spacing: 0; margin: 0; padding: 0;
            padding-top: 0px;" class="hero"><a target="_blank" style="text-decoration: none;"
            href="https://github.com/konsav/email-templates/"><img border="0" vspace="0" hspace="0"
            src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAOQAAADdCAMAAACc/C7aAAACalBMVEX///8Akj/aJR3/9QAqISj//wAAAAD/9wD/+wD/+QD//AAAlUAAlkDdJR38/PwAmUH19fWusbKMAAAAACny8vLe3d6ysbqAfR5+AADV1NXu7e5/dw/hJBzn5uedCCMQACnDyMorIijNygDd2Aq/vsVEPwC5t7gAgzwmHSgAjD5MQD7Ozc6XlJYAjjWmpKZuZh4AeDkRAA2BfoB5eYbu7AdpZGhyfX4Ahi54dHeVkpS0rgBlYGTs4wAAZjXDuwAAVQBEPkLN0BFTTlJxawAAYhtPSACnnwA8NTp+en2Fhh6fmQDEEwVJR0gOAAm+v9JVVFUAZgCLhQAAeSIATACrACIvdUDb3Oy1Cx0kUTDFFRynAAAZDCmelxxRAABjACeHg20yKidAOCamoFRcVgBZUyOTTCBWbFwdEym8pxZSUi+YhRyclRsAWzQiaDWcIyGgnI6aQCC7AACFkodoAAA1MAA1AABEWUZme2sAkSlxDCWAKSWvKCGMiEKRKyR5OSgxJQU7FyiupT8kAClERC2vq4qSjmgyMVaLipnLwzVODiYATxdIcFOrpWxfWESwsccAADVZZCNfP0hvjnVPRx0ATTBhPCpwYTpRTmNeNCksK0BpZygAPwA/S0NFXzJQPitJiFc7Nm0zSC6Yl644ZDSBkBxxLCajfH1THB1VXlN/VFWRSUkAFwCJDCSBelzAuE2zrWSukJESPC88AChJJiZGcCZodSh9lYFyLzKiUFDCv61SSjmsUx6ddB6HWSCcNzd3RCKNV1i0Tx0APTd+f50XJytBQFVgYpYgNQOocRweFQAAGC+CPCImMSpCLiThcsIXAAAgAElEQVR4nM19CWMb15Fmk2CjDwANQEKT7iZawqUG6QaaIAiIuAjBoERQFCWItMRDYkakKFMjU5QSSjEzOux4aIWO6XgS0w4tJXbW1tjxzNo7STwTj7O5ZhPNzsTZ/7T1XuNonIROuxLLFo5Gf131qr6qV+89gngiYpPV+Gg0msxmMyDj+R7+yfzuE5V4XrXLsuxSFIGXJNEWD1e8zYXDsuMrurUHE672dkU3aI4rCbyQk/TvR0fVbCYb5x3cE7vLhxJejvYr1S9mVYKQs3ksyWQeAGZ8urfDSfhDlMN5d8yu2J7cvT6YcHLUnZWVjqoRJ2cIwnEv7S3IBNiqHCu/bc8U1Grj5VhHJmZ/Yvd7/yK5kh15GRmcnBH1b2Bj7exmGAoLnVqwEVKuZNQKvM37+OLfJTXpHv16mi1nH+2I2osaHI3p38NeZsFDGwpCLnYSREwtvCvmXPDu8Nb2QGdxnEqVI/brIZyQzORVzWvYJAFeyGoQOJtDFGV0y53DZBGjgU4PcISSGc9ks8nRQAY+GuhmqVRieOs3cUWEq3DuryFINadqOhR98eziPhfShazI9ng0l8skYy40IlNMCSQVWUDOVuQVWQ3EVY7g5yNgyixp8IwNb4ERcF/HMBoPoD85X/TevhFvJN0Bf5F7csmw6uIlEeu3c7GsSIOBmejUf50bGNHepWiW8l61fT1BhsEfKvmrwwkDyTIUOZYsvsFJgk8dGL969ZCX0YP0Hrp6dSE/oPoUCfyNb5GiylreByA7hIrrC18HPxSWCWJgOUKylKaPRRQEOEEd2H56sXsk4fGmDHqMgNKQ8no9iZGJxae3B9Rc2ScVQOb0ILmAcfRrEDxHIfoPpNkShNS8S02un+tOpyiGYmgUOwyVQlEMQ8MbDJVKTyRYQzVIV/niUjLqCOtf+GrEloQhFE2X1UGnFyfSKRLZrmEHgbBJsvq/I5BEwB0o6pLPxeFPORcWm93C4xdMRJMenfukDDTL6JGA4kBzLEsWhGVprOCah0Cl9hFoLIc7otj5CP0a/3GM5mrI4mMVRzymi2OS2hMDx5D36Idd2ZEwSFORlNeTTifGJia6h0G6JybGEuk0HqtV6qYMExkVORpOzeQEuHZpdCq50SeoTFdmNDxe9PGOQC6G76MSZNESSSaVHpsYPrTvN8mBjUCn3OnDAv8R2BhIru9b7J5IeA0kSZd0Shk8y+sDKMQ4XFk3ZrXSwAbifGI4Iz8hiLYY+im7GxsPeARNqQ7fSxVBAhRIRcCnnFv/aTLuE0QbVycKcDab5FKj+d9swQiOULSmUmTZ6eH1uISsFnlVeX1keSGMfkbJPJmRqebimEkrbpWTAu4w1iIfmO/26BDSwF0S3YeyAwGXnp9xDlGSeCSQN+tSR1GBYHMIq5QuXsA7tm/Ahd60hQ95STIFf1XwQ338NEGKZpAGVbh1Ryabi/Hai7mxFEWXbZT2dB9aiPn40lO3CXIglsznxzOZTA5JZnx8PJ+P7g/IQiH5cPC+gauHJrxsYYgydCRxNSkQ/HZ3hMZ/HVlAriip1r2xRycOtQfxN19u+CU7yjuQljgluS9Bk4URRQEtSw/fjqpS8dYVNZbNjSdjcVnhgeHtP+IsSvvsqV27rnzj29/Ohu2KlmhJge3cRDrC0tq1yMSh7NV04drw12EAmBca39+jEC6OHqU4sC9Neg8NaBzEtX0oHSneBkMaEsNXB3wFixLU2Hg2psqKVOIr3P4jlvaCWCwWgGppnwWwVzL5/VqexndG9014SO2SrCHtLQdRsrsTotXjxQg8HJ6k/aURmgbfMNEDyhKSh9LgYQwF+/J0Px11FfIte3Q8G3ZV12z0IHVgAe6RU1d+nou5EJ0X1fwWsn8KO6HyUCe3FELoeNwg7UC8swn8kCk2vaBu7EswhQfNkN6RQ0kVj0KbEs9n43K9lLAeyIKAVmd3XflMU6iykelOM2QlVSBv88B8HjdIIcMR6ljh2bLe4bEIXXD6ZKr76iiPrZIPj2dVvkF9sQlIpFNne/upK7kkKqGIvvFDCZbVwaSYeyJhjz5ukERWIfhSWsQUBg7FRjyL91RsmIKKKgSNL9AcpAbUOX3l2/td8MCUgfmxVJkdMt5tGDGPv8gVVQkxE6kwIoql04fyPqxEOZoJNE/9dgaJcc6e+kZehUsKG1eXU0WjZdMAMlYsStsCj6tCguqIA7psA6I2ldjKatFSzUV3ptC6EFKUOqiRI7ryWZxHVCC3nNK8D0Ut5qVCoAZz7profDypdCAKg7K7XMhgmcShAfyjQjwTr+EiXGeNbO+pkeuN1Lnr23EIiuLGwliE1J5oYkEm7DnM8Ah7JBF4DBBtYVROFdaLIBnWs5hV0OPkkxm1Dql0vdRdI13Vcnhhur4FWyztuz5DzFgavTpCIh5Esd6rCqJ2iKfLXjL9wSPHKGZRMVXJTrCFuOhd3Ma1fiE5Xj876JwgW5C+Ew2HqdO569ujYCD8wD4PsllyJAtezZZHafQXKYocOfaoQYbzCNC+NOaWFGkYXpCRu+GjmUYTUgASJ8z1hNGEMjQDCTDbd+Xi8DO+8eEUyaY7kL1g58O9EgE3f+tRJyUcqgI7FnAph6ZGFgIIohQelxuOfwwyUiupVKo4LeKlyK5mIJHRPuVGP6HOj3gQRlvs2wi1eAMyTzohEI/Y+4jIKoUFD0mRnsUBRJRtai7QJCqqEySd7nC7Ozp6es6fP316L8juSulJ7QASu6BvQDoCNotz2NgVy1NRkRDPUqhiFrddfrQmG7h9fsNG+LZSZPe8Dz1AJRNrai4Akh3Z26NJR12Z95KH9+wUOi3tpzriHKTQcM34NwD1rqSEQVLUp9yZRODRKZMbGPamhmFcyldf2sCDMbZT2qMuI5D10d0PSDQ0n9LqWOFvONFfd2Vcr6M6EnuH+CDiCTe/jfuQgUUgN5Gr4Ot8+OfknLpTxVcdI9mxHUB6WgIJQ/PUZ2FNjxj09XtnEPOiAWSK9DxkKBF9A9vb0U7RluwGZ0ZRfYX5UimZ3XmOP7AzSHeLIJHNPpXf/w1L4bPO6d2o7M58SmwwBnbuoaqVvtuLI+n0SPf4djcFcYr1zKsYnJxrhSg/UpAwFK9fwXq0IKTOE30kGOwZ4hV49qnLDw6R25j3go3SpKFDw+g92kkEskDU8y2Vk+IAcu6RgSygg3xsehr+w7nnGZpJBabOohubeHDfox4ysJDGsamFCZTY0Z5+xHAC47kWi0n1QFa5WQTyk1ZBYjs98tH+g/6Z68525+8itEeZehlA0t43HhSj4PbSBpb2eha6UHJMev5bY2+qq8ULDIyw1SB7FhZ6qkHOt7eO0nnqQ2l/0GS+OGuxTKdJj31qjkFzCxsPiNGxnSApKpG7vXuOxnrc7dv5S3qRt8ZIuhKke/fI8t4qkF2J37WM0vlHGCcfW9varO9BKHmOJruwuSKQ6o8fxPtsLLIGciLquzeH0lYyPd93X0X6KdWzPFcNsmN3JH26CmRfOvK7E3XTylo5AtkVtwQgTf49TssJD5n6IAChhPF+QPAjh++f+/AveSGXSvKZMWyrabfHM9Di8OY4mxB+OUXWgjzdx6S2eqpAJlgm/Yc9s4W6XY1UaPL3EiEPtoGY7s46nb8j2denulgDnZ4iuDHyxtR9YrTdS5BMaqEzg6tzdAKiduo3NSTOps3f+Fwu9I/LpSjKF1+88srZsTQFDLcW5N4ETR4+7S6/MI9A0hRLRhLP//a//vd/XAeZnp4+cQL+r8msHqXz30XC52/DKIduzk4/Q3rUzgTNjnGEOEJGbt3nhHTgDkkxE+EMblkgE/19JBU5VFNWCXiqBRKLVIRmsfbnlsvetQfx893zXgbG9t69p0+f1/QJtO5OgsYZOPxABL79TIV4PN36Aev8iBDutmli7V35fJk29B27nCIB5Afo0vc3hyDMpxg2vb2BM0JmZHujC+5hq1qTnR5WSwvpkmhZIhY9yJ6trq7Dy8uoPkSOLR8+3NW13lMCyVbkmJWXoskXK811VbNWU29vm9X8ryna8INjN8gRG3EG7pS8cV8g7yVoJrLAJxNAK8ixHL8xwlLeaiYnvawv3JVyxZJMlEGe3/LiCWZcJEaSKIE8N1eZbRbT6sJl6WculVVpOfLHpWBbm7ktdOHKZzMrQ291kbQ3PABjUjxLooLe/fieQB9N0d1xIjAMj3Isw0tPRyhypDoYfVqYUKbTscuVYgeR5dHlMq073zNWLvkzhsN7McYepMlr36yS57788rnnvjxMapenx3RFIIvzWgggfvitIx9JM73+9T0Jlk7fS3mmjr2KqKz3Pqi60BNh4LvgJ+8tJoazIpEExVJVzTVEIMXAbaD/kWfr5pWdE3ruursvUiq+b+0ujFQEcrqmSonkm6i8gXNG9rcVw/LSi+BxPvoFLxw3mUzvXXqGIcfSHt8xNBKo1J9aBzkwBsNkAQVXsXOgUyQ6FxmKnahSpDBCw/gCauVhqcjletGlc4LV5ZPuvedSmmo8C0UHi0Ceq1etc55I0xSzTFJpL8NEblZ4WIvTCSk04Zs0oXD5HDDOlLdz6mVS0+TlFjkB91KKIZfLmPgcUmzVVIutGyx67gzYajRF0556RMHXDSDLsb/H7dVAps+XXppPAUhnDUbLLDAQ5rddJPO3b7MUnb5e+RFnHE0kBpGLvTD7PHwAGE8MHDoNY/LMWGsofYsGitbFiyR4HcNW5Xe5OALueyVCp/lb4IlHagKxpGx002yiBKjjfB+QE5Y2UJH5Hj3IPbNoSrZSfkeDc55FIE9MwMNcnq3kBH+0ES4Ym4j5XL8OOjcMEEoaCNphjrB7D7fECTq7ESh1oFOLrZ2Amaw2Vp+Hpr0q8UqETfPSWXD/FdVBjo8vnfSHuhk9yNPLLEMn4JbIO+f1IFdW3v/werue21huPgMBbI8TgZydhkfMflmpSWB3vpAJx5KZdhi97Mgx4gYM3x8QADISb4WZdQ7TjLdjcWIRlwH4eTDH9HjlR/gxSObOEATWJDE1xzK6xFVQNw8ErWZzqA8srUziejykt2/37q4Imdjt1oEMWa1W/9Dbl2aL/NV5Anym96YTg5x27kmTjFc/LC3fchGulQInMM/s+S2Y9g3R52HRoDmTYtOdxM7Cg+r6+hgyMjyg9WlSkatVxnoLAhlyqaDJBCr7pMGTF5IUfv/JyaBmSn0wSsoY54Hkgxvafc4b2V18bQGBBJWYzG3+u9c0mJbZ5+EXn3NqIMGWb0ZoekTvnpwqMWMtgDSZ/H+Gp5CKTyXIMVDKHbDCT1sASfR4vXvB37OeDgKFSgPZXTW3csxLsyPxLy5/cQN8JcTFLz71Mgat6TVw0Gou/H7vOfC98+Uh2bUbqdV9fvdy0V4RyC3N7kAn5tCHszA4IbuAHOrLbz73zWWSSUDI/GYXGOSXumHrvKRqI9Ic7PW3ma13vQzp+c9X6bMSMZVgDWyilVG5MdF3GCXc6R7fwGIEkpF7VVxHBOeHSU0EQhn+D2AbOIyGJ4sQQbZStLfkZCCGFP9rr7ukyQh5oQgSYPa+i1wtaNKQQuQHxUlMoyD3v14RRvYMWQHc5MHNF4ZWQm29/wjIhj3syxLxJxy8WwmXYnbei2Jr1/ydBDDKyL6aAuuZMvkq/Ad9GLmpgB5j2zrod6FBWbkA0kAu+E3lb5iHTjjbndfoqqsb2LnZStdzLdQbesEu2daCvaGLM38PsTqVYuck4jJi+2SsDqgaiXfj0Ho6BWyTYodriwuCvkdVm+xG9Tv5oB6j6ZcehjzXFOQ6Sf5ZD7LNGrrktMxWX52KfLMqxjhnp3+PqmlAZU3W3pvfRE3s9Jw0dRaDbKXcLP0Daosnu7rQN8mJ7do0DU0qVdwGCeOBsM3oMbaZ30rD4DrdDOQ5ktzd21bxpaFpp+W5SGU3IjlXQ4ssziOQWKmTJvyd2TEAR49Ix15FX2QHWgAZGGbRbEqPhzFE0lt1vzF1g9Z3ZtAJxP/3Byvu1zQElCe9290Y5F5g4X+pBNlmXZl2zv5W3y4LHnBPHVb0LXDnAe0XzW/vgZGBQKaRL/G0UrzrR22d7PL5xeHFrYEG5aupZap0HxSbwMYaMleCDM1DLNjdGKN7d4L0/tlUCRJXNqafj5RaEygyfbMWIy6FKJvaL5p63z9HGuiENDWCM9YWKgQqxElQ5EuCWFzxUE+EWykKJ7Y0FelCT0K6G6y63bY/e2m6r0l5eXeKTPzSWv0t08ysc/Z3XtzbDDk0NVe3/Oz8PS9eLP6iyRSC3DsVtt0CJ7JTnOQUn4+/hyZa2bHtHZ4F1/kvaY/X60n/SwBTurXB6rs1X+wmmTIdr5HTwDj6hszVX2uzzsC43PPbxDPeiPeZv/2yDoNH5nrkF5BtYYTmwV6T+V9ToPJjb3iArX0Bd2NrqB11+/R7W5l5VPOg+3cus4qC8sUXiqJRec0HVMn/S9GGvoau53Sajmz11n6rrW3lhBP85/X/+N//MT1raVCttBzJo/EBnPC11fxMyJ+A5OyMeAc4qIK6uxs4H8e9RQ9JMltIkeRI8v7mF9TJWo20WS8+TzMRdwNd7p5g6TrWir/of//SLOq3szSCiFBaLvT2+jfzP+KlIWvor7+KMIzHF0ix2Am+sly3FOK4N8YAc0gvRFBKvu/+6uXqwToYgdn92cOynvm6KHffAaJxLlRH/22Ykp5898U97XUttYRy9uaXP+I5BwG5pdn/CVBeww3Zi0Fyl1N1g+X2MhANhl0YYVGh9ej99EGL++vpEd1raAFyGO/W6fMdVZHk/OmuCEOO/LLu1zSYpjb/zM2mMC0W5x/h57k1VN2auY6qktEUzm1tt6h6DTDCvghFR5a3sCIjW90tzLIWRLKvDNbXB9jd0HtekmZG7uzdW4bpBpK+lSYpNv2X3kZfLHy99+71JgYLPvYK6gzBiYz/xPOQS/QBuwOQ4jLprVOFHRgjmcjixvYyicLpfGSxRXsVwnfruZyimC/Oe0iGjXie312sM5/fvXs+HWHBGfaE6huAXp+hDy2NlWn5FiDhfoKvYv7kUopivCn6ZQD5gZeO3KpRk/A9IMPDKn8aUX9yYYT0tNBaalNWXzv+neY3avX/pc9LkTTJTHScd3ec37vVl0iBctnU83/x74QRwbRerB9DsCL/XSJE+0H8kK0X2n9LGiC0AkjbDRLYTE0NsbMP8u9tm28RT5vDSPI+vaN79a0dHLQ2tzf0hHsv/rVvJELSrKfn9N71RIQlGYY0jK2/tYOtli6wcr0RSgApbhYMyRSa3oM4L3N2ingDsbxE9bSG7R5kDN0q4XoJsZi+c5Avru8AUlrzB1vQRBuueP/yr10pmvSu3zGgiZKIt3vhLX9rENs00t7IXF26+Hx3+nlEul+XxNdRYlRTQhQOwUN4WiIc2xPe1PLuO6DW3zQHKd8NtnyXKB26+JflFAnJNesZ6fvrny/6dzaBslhnZht4H+fvXygHWvPKi17wmrdEHk0iMal41S0PjNFsAo1CKfPfL90bmCCZHcak72ANU20O09z71nspkkwNu98K+dvM9wERpPdawwb9BXhaJrMVidl8EQg69Qoh4P6X6khpexoyyEWtAOAQie0Uww439a7KSl2m0lSsIbcnsfui1dqakesFMsZG5G52xu8P3b3w9jufvBMyW9/CjkdBaRRTHUNU5HYyRfsUtiBZvNesyZtbuj89FlAOLfy5FYdaK6beS418j2X2+vXpWee3fv/76U/utoXSLIxFHs2MsFWOx7HtocmJEvCBBE2ONM2u67LxFu7V36JDrRHr2w3DiMXpPDJ7KkB0hlY+vPROH+jn0yk8Jg9XhhBhAbRcWtBmu5piqH3NaJ1t5v6N9eHEOtOYETj/aHfJHHA7q/+S8/ozNDty7HXE2qpmoTbGgPWV8sfOYZb2jNcg04mvdff/iMS80mhQtrcfwT1wMnA787uzs3MMFfmTGgHu00kIel3eRtbaCRrCL97z0lR3U7ez+iAj8uFA+hv047drk1ySesCM53/QxCZ56w2I+jck250f6wohbngNvKmSvKfaCGWdpCJPN3M74uYTB9nWe6Kh53GGCdualgb1vug84aHpV//zVdYwAOROP/XcASBHNqSFEc9VldgYYdlE0z4uvkES+FiloXt1XuMIx5uFst37TiCwVOqelxwTCccN8uXyjMF2AqjWve0RkvRkhXXQ91bTmUzl4FcA8lojkKj+Kq5od2Qesjg/Ae7WF4mcIVBvT6rsfXzDNISV3eBUU7+5l4AsN9MMI2F/sADycPKHRmzgW3L5jky9e5yzECrTETTJtpFi6HIcEb/nYRnvORpILWR/Bma4+Qzfak1d7vGL6d2GfuefwLSKIQ2Vpn8LOJjXRUJ8mTSUZhQJ1D2fIhNdkJ6MQc7MeuabV2fXnrzfaTOdbMjRTwVO6mjU3en/iFBUZAO1p6CuZh2BDSx4+oAmkOfSLJvq2aG3YPOBqNlDgvTXK6NrKHeFzCZUEkIfM5lX/s7DoBaJqWXUJcroZ7h822g7BHohEknM71T4eO1J8x0k5sacx3npbii08u6FCz/+w7u9JuvQHI1AXk7VgCSkQ/CKt2d4X3KnVe7cs1+BJsGnNIyUaCJvehbNYFra3/Zb2/4VgsgHBF4DWZVUqhMkbuLdeY1XoTr/pMX6bmNm166V9FAr16ULof9joKjLU3iSkx2pwIM21KEXW9mroLNhAfLxSm/DUNmOcxGn89S1XU5n+/QnaZZ6/Q28dI66oQfpuIes9WoLGInwV+BckZhDDQtakFXG4v/0ucKJ2Zugz8MkM/cGKpJTqYpURNlCQSXZEFlZbGtfhd9BYm2cijg/R3cGnmWld73d+TvwPFNjqCXAUxHxVXiNWW6lzUf5KphrQS40DJb/hO+NXwqae29CJkJ7JFQlZ18uzRXYlI3t216mXgN2rXC185BPTkwz9ZdXWI6MAgzX6rMwkkwX2mefYVOXu0h9iwS/fXUssZACmrB7YOeJ6MBXQVzLKN+ri/LIR3Dj/LODaCCZ7s6i9pFbN2D8lVIt2Z1gSU8f6qTsGhvfwb1y8QbzV08KZO+L9TYmuO5Cj1/z+kAAZ/8WcuYukqLuFG5bcHshQB6eYw1k1wiZGG86mcU1mqN7YmIO1ammO6+j9cCFiXkA2f5fDHl4hGQSwN14Hm8uCx6HvOCBZGvdy7ATzap0tvBXFCJ1glcw1QxJO+ErlitM4IOfi5BzXjqCOjfPvMIRvkVITFKHFlCUXICEkllvXKYDn/OVY0TzOrUG6/z3/ceLJgaadO4B92ogl1FZ4EZiCtVYKfLCxgX4M3F+gjLoyq818tX6nJLUmTKwtL9fCt7wFJx7gJzTmLZOvepRiIyHYUcGiKfTdOqQso2SlIb26ttxyvSJSN302Tk91GYyF/Ktt1E1i6K6EKMLpMBon4ZxCIy187+79w2gRQ5Mw3Vn4leRK9cRU6geI3BOv/juylDIb7aaTP5piCHaVAg/x9C3ACRtQHtUKnEXDNC+JiBdX0X5qo6Y/NfrhUoL2lNs+ubbM4Dz3ek5kryBmM2ZFEV2IZCRfUVYTUE+0BzP45DeBjUCi7Zs5lqvqe2d50kGDbs3PBAZ51oHyX0l9YB60vtigz60ax/dPOJ0Hvm/EEz7SHYU9XIi/jrSOkjh6+FakdQH6YxxhKiG47L8U7/1hySirZfRmqL6IOtbq2/yq8ZWkrognbvK28c/9e67CCSPWn3rg9y215WBr8uQbOv90mmp2WnLeeTzAgibGn/K+QeSPEOE8b7k5HIdkL/aVVeu1G1nfORSrC02+YT/50/Vyud2tEsPz6+tLk1+Z+UTABnmbuCdrtgbdUD+Td2lfs7pxzMnWXlR6+DxAwcmm3s400G7q0bsKCiKaz87OTgYNJlC6hmaDOM1lXjTjCJIvGGsBrK+f26v031rNt9nF0e1BP0hv75TZiUgOUTfkp4im0zBSt2aTtZJ7W0qp6gzg4UKs1+5zJDxTryUkU4LGkgbYYvtTfLNQLY7a6bQzb2hu0N+/asmq9lc+ffmnR7BTdknr5WyN1NIK2vbdPOf1oN331ypcOzBN+tlg7G14+XrAEiWDH+BVzygpXJA65hDEhE75Om+R3R2NwH5YjXGoZuz7bM3V8o3YPLPvPjhTLn3wdR78f2htsa6Nl1EOrHJQ4WPWDcL48Ze8uTBGUV0iHG9agfrZRC+izp9m0/yZ0h6+1/wiEy/QRAZL1oQ6liPkMyiMpCm6XQDkJbrlQUsE1rAgYrXd0trw/x70OD9sDh4zSuXnM72aw1pvclf6AuT/QWQS4VblouqCy5pZdMXyqo1herO1CzpLAge1hnS8D/QkNRSke00TUW+FzhHAv3ZPhehyLFPGhU3L1SALJZ6nSeKqtM6NCzt7xbmCv2orm9xXm+E0rxZKPyKhRmkEsiiJs1DfPGF0m9bN+thJOzHyyitMeJT0rDtQQtS8brOzm4atbdukQY2gZJmstGOgICmYlVVqQbqLK7rMWs5u/Oa9jHr+4WncLOBXw6WpikKarBuFupoxQnQ4P7CB5QyyMEGuyuqQ0UPZpqUiRuk9wJaQaZtlSHd9rIG1rsOL6TvgDoT3288rfK2TiXWC6WXvyxEUPO6BvJm4a+l/qILdTGaJkt2VwBpOqmV0bii4ykNP1cJpOlAo7Kpsnk8iLsSTcd54iyZTrMUNVFoGVC3ImCw6xGK9lwgWe9fG8+qWGZ1UcR6ofg5y/WCpgoNRSVNFosxEGLrGaz5teLt2TYLplYYpKVps5LWynPbwc2GzZsOJT6DulNNkz7by2SEopgbpUnIwJaHJNfByaYuUJ7zjefH0Dygbq1jaY7JMhsqdiXg71reK4ywi8VLOd+rF96tLxTvgC/OFA9qa4Z9Jb9TNNfySrfBxvthKYpC+FZPBk3B8BQ4HSaCbZVz4TGgdnR71z00Zc1JcSAAAB1oSURBVFi4427cEoTv/x19JaUE8mSxdRjjdr5YKA36i8VD56V6o3JwtXh3pQavgnnGi77UPKN9QDdZONloVyAuoAhKXCL4tUHr2jEPQ1HaeOQXC85rY/t2Gkbmwp4d9v6xWMqPtPfLGpBa1xRoVvuQ+Z3S1eqwJdNkace0kjMtjMkSSJNfs7f95Wd7slH1G2+nZ5PjgcC4/2d/SjHMLW08nkmXyo/JBKTQW831iHRSDpamu0XkRXMtgGx3fqgFFVPJAVveq1Wk6XjR73AlZ1qYuVBKigtibQsny6PkZ/Urpry9vNez8FN/MsIsaxjfSHtKj2VgDED21VmmWK3La8VkBPWxaS8VgZsLFSZL0Z2WehksX9amMKaDxdstdrGZXyvEzZJ3bTP9TCL0BAhia13nyqtSmetxgYs/pAodvRsJ1lN6LBsTtIE83JAHlEG2lwhOsQXVWcJddKeW6RXNPItBxHndXwvyZPHHpYIxT5b4mi9UehJocdmvy/NoDTRZsVGwGE7+I4PXkUtnvCRdNlffMFpcuTNIsMXi8LLe1YzRuV5wNKFSFa0QRUxl1LVzmpqSMEhtnZe59AJhK1Y/NZBrO5K6in3JA89uj5FoGf7UjRSLs5DiDy1CoEz/XQsbdF4vUVOtfaicg10of+gSVm6p4lTyTToJFkkdIWp6D66VI6BaBInUrddk22S9DR71G4aLgcmDnWn27BRx7DCJWtHnSj2E4r4IBQlI03VRhfstbX6gDUFLMZsuuVtEejDz8F8qOeC7Ne41+GYRpEMbgkHdcPMVXdEqAm7XTaXpH0VJhJ+s4q3YOd4X2Jy0Pit46Fc48RbetYg6W7qsiCdhfzXdvhNMHUjNeTpPFH5e1wvvfLswG1oEWSTtepC/Lk34qpOaJZajQ2FBtvUuvkEuXKau5rq07mLQv7m0tLR50j8YNJk3v0hFAoSKj+uiImX2YLvtBZA9/3bh+yeawywPL2uBqp4o+J1yzRe8E961QteScqFGk4OrJZWIGq3TWaI2Ck0Hi7RMXSkNy8HqJS1IVgfNZrwwBN3boP110vMGoR0hyKTKfb3yPyCQW6mIZ735wCyNSTBGZ0G1BQDvldjs7ElzOWziV2qJXZnwgLkdsGJLLKPGv6FLOPhSXaLMBnUibep909QYOTf1hnbuGlneKWhjawvllee8DM0ebpyHtJfpd1vbejHVWi+yuuulIYhcSTHVKttvJUh9gu9DDtb8LFe6Z/TcrEu64Se9VkzoTtYLItLSYNFWgqvHvOSneI83dLhTqbduY19kboQ1UHe8JHD3f2sWSYpk27pS4q7Xi/PY60VnqpmrzlqdHzYHSXSCbylnUSLqtoZkQvcB7tdFh+uv298orR0sLI8b9AXYVHjqZW3/uISraAsvecm5CdJAHZ4fMVBM5O+bNbFpdoNahEsILmkGay7NqaEnUWJEmv5rQVbGgvikSZcqoqYv87P693cCCZ51fwilzeaVqdfJhOTD53yxnpLFD4yRdKKPNDAT6kAfRTXbPFezRPgpnS2C79H2Piz1MaK0o2Ia0flJjePprWyMgvhvfa1kngKYbznfxO8XR515pY57FWQZXLOACn/mlWOvsoenbqFSHevZKLpw6Xsphk7MkwzqH0Srfj2NR2UBZNHrFDHMrmNNlZJRyFYqQe6p2fyiWiGyv+x4IO8YNFVqUiwufy/lmDqxywKvomNa1YNW80nVG3nljQRtoMiEWnpsihsste8f5iIj90TCtpBiDD9sUh7A5qqjcAWUfpPenQJ7teobGJx7qhVZA1Lc1DM229qk9bg+qyoW8IIXq3tVOc6Fc0xV5m1oNWDoBuP94Cxa+Dun2+jEt0AaIj/wnTfuRb+CNhEe+7vGhR40x1k54BCodhiW5VIAHqf6CeESYyiDrCGhL1RwGXH1+Hf06x8LOab1YHXSrKj2wgkQimxXZV/IP0LO/cBA0akbx9C5ZWVNUpEfSA7teCFhMcJEvtvE9cygR1o1EYp4UGWXuPPmkM67Wqarcy09vyncRmVo4JQlfQjR5rlNk9WVZS5sK2/zYXO45NXXUuQ5GH9edHgKd+bTAnUXYUxSw67iB7c9TLPMUsujzG9VfADM0dT2XqXKL+k0aamZLqof7ipF3+inFfQG16o/I2uXKeGMK3fIlJdk8PaevlueL4pvYO9amntVUQvI9xsqEqUYJl240F57x1qz7lhPDx8MpF7whkbmgzWJlspJcCF1KSyEAwTv41RUwyINaEHd1MCIbtsIYV+ESV0tOdvbwGp/2KQS4lyv8KTtGqGdmW3WPD1bXZU015ubaiIK6rgqZy5Fcf105sDxnzw7aA1OBgdnDk4eeOFMhGHTMRsxdWaMIg26afOeNI3W3xdkIEHSTVyPVu+w6g3a8ofe9SajGIOs0eT9gcQtb8FfV+dZ8kGryYSnzky4WcnqX6Yjy5B3bbycIilyQreDHTq93Vva70tYNNDehWb3fKGtAqRl9uI7zet85QTtQUES4seDpuBqNUilql3DFPKgbmUu7KEZA+PVTynwt9FKO1fxr0+D67nTpMrsvFa1SmO2cQf8o9Ik8qOhwTerm4756pLDv7GRDcJxK4WYK3Oj4jeQhZbXTA4kGHKkib2C6zH79ea5Y0Hh4cckEmHp45r518od1kxDaTJxjAjgNIus2vXMt8CA69GuYEOdk2z6b5qC1Af+FuThvWsj4SpX5b5LUp+ifWpwulzdrJMBG+5GlFkYiG78yMOwiWYgb5arjQ8O8lGcCcqpalw3/Wm9mCDTLmIjgjdovFHtigMTFO0ddxBKz5ine97LNK3BWt42NVksXvextEDrHkBsYdFmj5UWFpqHfhyhbjim/hda9kKWV0sUxTGfosixbSE5QtJk3zIbaRYSZu/6L90XxlaykAcRFZ35Zx8YKpYmAgnS26k1m9EjtdsQor1qDUwi1+MFz+s5TY40qYFYpt9quJaxEcjapLm3lYU2zUSMx/HBZTZ+VNuIZFCNG8izU8fQ+iUyUe/ywt4UbWDJLZSHUV19zRg66rm8P4w71ngeROTyoFYwnd489iqZ+hPaVImiE/W3k1QPoZp6Yh1tDeLZvVPgu1+pLUnWspf7FP2RV6hxwvrxKxGgOLciFEWPNTKTjfk0xUS0rfm2dp7fuh+pOxfyAIFSL1wAbUPusEk2CHrSDDy1ZJr1qp+maDpyq/F4V7avdo8cOod3Tf/Vo8TY7nyxztRd3VmNVsVm//WSfXXl+N21A5vy2qoYDVmH+mj25WyENCTQuetEo32XHbxvQ+3A7S/ngLXtPDHSKsYT9RbqmVYeIlJKPwkGJwdNJlPQHPQHBz/u3LT+nxTEBC/p+RSfSyvcaXb1jWEDZWAT33W2z87ONtkyrr7UHknTbmm/Gaq/YeRKdSnDhs6Pb+lMycq1f6bg3Z/6x1h6ORK5hT3OVCAx0fQZnfaiDajX/+773/3sV3+z577UiU5En56eLmx1iRE6nbPvNWoiNYXiekSSuvazkyd/9ma8BZrAVW7oYA5F/zXFpFLeM8hKpzbOetG2GE1kA82UkCPrXnRSeN93G++MV6PF9pvrKyG/3x9aWf/w0jTe73r20nuhxl26psG7cV4UHaIoCvb9K4PBIOSEwWAovKM2xcq5wOCbA+AwaS8+wTF8OAW0tPmTEtC20hTlRmOTJtMLzTp7KjDevNhrxbsamMxWkz80NHT37lDI37wZ1Bw8PrS5ubly4PhkeRM88+DSTigdlbx8cD9eLRlHhjoG2TJlOLPDStAoOrmHXe4j0XlDrMfdGk11XvNXdPiazFh2bPrFuoPPVXx3sE4FuVIqzNXkz4LyvADs2I0UjXb+Tux00I3vv9GoTM0vTySABZGJlsKJ88SD7WPWALl/p5PKJP3eHNZfoh7WPwFBGEEz6HX25auRWP8c6hSd+J5v42oarOBOS8zgvUfaoj5YU+ioFuW1ksGaQ33aoRdq4Tjw2iyrWlzz3vMU2j47JxHCbbSHTZOmwqLUa314GCm3TTQUoeR7et83MPTZKS7u1XbCb+EA584J8g5ao08OA4UWrkZQAr0zyAriNhhstJrUPPRW/S0oq1yweWXncOkrzAGZL4Kxej8oFD0Q9d7xUCZuIE2m19EZS7jevDHBUOS5HQ1WD9L6/v61/XW30zQFL6r8Up1l0Sbr5AtoJqnc/zDUArPV6jvWoedpivox2rdW23neu/PRBDa0G+HWHEmSiygZst1Ls0xqfieD1dccrT+VUFtUaLDKtZqDoVjg4GuC+rPJSj9smjy51ukLrwz6N4udW+adzZUgeKRK08VzJMWMiaoH2yptSG+0sKH9RoKlPaeXE905XNhStiB1aZZDazL7bkk/1hfwryirzw5aS2hM1uDBNwNrfrM1tOqzX5wMaiHVbLYOHti8jOmmsprvLPrMwVYSMdSUZ/Kj9RCpjQ88eFts0nOjpWS8cxida7ed3Sj8zEY3Q+3sYZ03e7UpaNM7l54uziSpSyf9g1h6T26GfXE8320KrsR5ef/mSSBHoZObHwf4Eh6HWuhhNodaOewStWpB9GAp9sKnKXwg4Minna1lqcJt8FX6/TLH0+Cgm5YKsMG+7cdLX2aK+3BgkXyqurp62S4LPvtKsUHDPHhwVZEkwecT+ArTUpXAQdA+0KAG3fRVsjpoHkJ7lows03Ti7CtffND6WXcDEyxFHSpr3TXPUOxIkxKlBrL95vtDQ+9fg8xF6yqRyqOKEwKboUGdvzHD8NsvVw87xQWfjM+89toLjU+drwLpR2eaRFCCpUgt72mOpQdccipXLv5uAOpIs32NChYLmQc699Q5ioGFfzK0ubYKsjRzYDJYs/uwNTh4/DXtA6ubH2NfWihocM0Q6vfA5H7d+28RSPENnlv3f7xv50ugurGywXJXUwz5j1ohtoUME0Bydhshrg0CEJCgnsGayqklcjtB9InvHLDbuIBI7HhQOToGe7T8IdvS3RRNMeBrWspBq2RggqQMi+WxHwXVerC9WqZv7phhOqME9z/teIamhp+b/S9U8QSTeXAT0iJ1RiJ2Ps8+kJeiZZBKdwRI9ssPeHS6eNsDBnu7FI8HEgBSiyI/Ur9xZCdHC45n8wDqOLEfrKQEpuCQaotXvGgOHkSZs+/AKrEjSC48SrhK1JuzJ1iqFQrXSHz70KmahSXcDl/Ow5ZA2nzzO6B0/jNHXB7E3avCki7um4KTS2igKzOTQbTeFVVoggc/RtmtbyikoDWQzR99FJ5CoGRfKj67paUz3+oLN9ANnnkRX0C6OjG35SGXtTH5uY2Qxnc1PxThkkAooeAm9lydayEYlFarNTgZWvPBlW34xZOTSEKbuNTB2Q98BxJIvnls5HPo/eKx7ZyaxgekPuhZ20gcOP3AexEClyW9C+lCA9OHEMHE2JVmE8uWIzJqYcVDDT6srC5dfO21mTW7gPCpH2N18Ypst7sU7DCk/SHrAR6t0Gl2R3IGwxsvDEmMkfS0QuEaCzJYOrUvr270RNCOKPMFYve5MQzXVX/erA3iyEccoQ6azAdXi2sgSnYoH//OfrC58goHBw9j1DyJgr/aJNBx4Ri6lpIZ1f6KmSrtaeWUsGYCHhax3bFE1xy6XmpLq/VcSxqjcDPK+KnGJuu8JBHcC0EI+SurPgkDFBX7qozqT1bUb2R/9uDmqmqXZfvqm0BxtLWgUpPJET6JKZC93ygXMCJb9YQfSo8E6nRJk0DNWdZwDp26TUfm8ZrPK3zYiMaFLdnEZI+EtUZHk2nQf3JzaW1p82f+A0gV6iBKFW2E8BoOkDiIogQMaSnc2O24xl0IWtyYO4q1jTNH2ht7WIyIw45ESIZiSGYhwVAGJoKySstTAmE39qPRY//slAVtPVZv35hTcFO+FUzH8bEBwck19BXcRY1bxyATK1bnzJNLyBHLDUekGM4jNNK4MSZkCbRAAlUA6BbSxhZE2T6U8KZSnu6Xkuh0cSZyYY/T8hTcvny0H81jCPkrzunP6oZN5z/DfQszx1HvOyB8dg2vaMDaLfSac8rSgSDCP/gsHrlS/SAZD8PP4NCiZIxxzhVDMz14PEZi98dVG4ovun3v3vaGyA2M0aBL6oefOJ9Cg4IfN2LiYf/uZzY+/1Sdw4Sc19CqFd/+TZD92uGyXHFpcnFVMh9f2txc0k4ek+qphXONq2omi5ewx41uF2r3JLjLXnyERPMK+X0Jp+US3MAyttgf7tmF56LEmDGJPHpGRl7gR7tqGK3FeRM/f04sHiTnijsKxVIEUioE/sKbcr3Uio/FeELGrkbJ49/jYrztMrbV1E7F4wcCO4roLMOc+7bmAznV6JaJgDGDRpIj/I1TNV7IeeSP9oJBcZBq/fPsLqkIcgkdjhu3OwoIOT6s1NqqLTwuEHzW6M7wXOCoEVuzIypqeox8+sgwynbZVUxruY0JdM430z1aeNOVMWZjqhucAYFOu/35qWqjtTiP7Prnj37xi1989Mddp9DmIULhcAq0Kl1QCD6gyorL5ZIDdeicFBhXCXDkHWGOz40bC7sH89HLKXxq5K1HBZGQsvZ4LJOLhcMB1FUaQMc3M9RWaV1DNCcRUszYE0cKU2L1tOk8AoKmuLQN9PAic7w6VEBGaOMVkDpNS7ZARnVwgQ5jFL0pG4s5WOcWslWGvqXXo014kESr9G0g/YSUM8bkeDQ7Pp68Pcygk36LU9VcViEgbRSSRiN2HtL+z041m7h1BggJVaCDaDeBJhSOk+I5lXCoRmNeQbvPgIstjFjbp+hUSsrQh6Yx5fhoLAMyns8+VCyB1IYDfRpRduMAtrkxbCAjW0WqNqoSLiMaofasMYcpGR//7KnZhhTBCWQPHU+BO6zVhk/fNRpVISHJGbN2Dg0Kt0TYsi78FvY5FNW1nYzF4gF7uN+o8pKNsD8cKeBGIS458sZiSFK3uq8WUwU5xhHJDsEFXs9mdxtzAfRLDvvTyGrr6tN5iSeEFavWVNfg4TvU8ahgs8VzRrddWznfk4tyhM2NvsO/yjIUxR6ectgQGRZyR9G9cPHsQzohLg7xEOhUcUdUsbS5tuQWCVd/TDVqTxm0aYzjDwn7s0+daq/T6WM5EkCrCPEqs0A9RfJyLAmPSgmDoYIWHXa4sssoI2sRkvCYvxh59X/9yyuXCx0PstGNPXs09pCtMgglOocyYMxVjSExx4Oe+3PGgAPcxChPiHLG2BPD41V0jX77yinN3VSocpeD4Nb+J1JCLRd3qNFsQOAIOdoPzw1ZjtAfRSe3y2EjPDw1hki+MFU6vlXVbknM7lwzaUHUDFiDy22s8PNcDDgBb+xH90HEjDkj+kEl2mHsULVSsbJ//PNd3zoCcURnus5/suGsSwpUMDKbpMTz+TiMPT5+1OgGBgBPQSC4aIdA2PJJ3j0ODj1cQRe4UWMG81n3w/TJ6ARnq8K4May7MxXZSMyoHkWeyRgVjPCg0WIp8BfGmIqDjE2xh3905alT+i6JIx+ha4jx8mSOA1hBNBq282gZfdRozKKeQEgBjEd5+BMUPuoeNxqj6LG6yj8vRjU3oXQ8in5SDSUa9kDkxkv3pqAjuPijeQ453lGjLBlHCUcuL6NNRiCiuPMam+Eckiue/ezn15469a0jeDexI08LhAQYOZtNFORALD8eVRXRhoN/j9EYRszDZSMySQGBMIJLUYFURd0cIWSM5ZWzOSPOy+TcI8OI/BgyCuBWhcK2lO+BEMapss0YIMRMFtizCxJaiKiah42BPjOqqzjHISn2wP790eSPfvT55+6eaC4Wi0bz+eho3K4gddgg5HUYjeNhGakfvI5CRI0y+jIajTyok9O4T9GLyu6jaExz6vijaX4uosyiUKn0G7UJgKgaMPbH0fOHO3AdjRPzwH1Ge5TRfmBuiJ3wrpjRaMxFw3LZMG2ihGI4L8D/eKnIWwU1lgeEuTiiLTzBu/tHFXCwR8GJAc9AvwfPjwP2CJEqoFUj1aPYAxCjyYdrzquV0SjcBBc1ziMSYsyIEowfiGSSAK5ckUGhwDC5aI/gyMAdu1ByAUMsA7dvzIyqCi9JDt3ByRwCDNaaBAs1usdH0aSIKIuyUSLyOckmQWBU88YwYUsaRdRGp3EfTk3a8LDBuZeYjz8Kt1op8XFcLQYKh8ZJViTAxyRRMBZ6spmjKCXqz/bnbeCFVMi/4gEZ3ZBgDyDTNRr7c9kkcOA4SDg8Gk1mO/Cr2bCK7BLd7agxxhvtEKzCeYjAhCJm8yIhg0u354FPISIITtyBMtlRFGP5bGvzXvcpCh6YfN6YFVCQklEeiwm0kuuQkasNjGck8IjwBmfLGPs1/sBxDvAwaiyZcwOqo9o/bncmGlYV0C6B73c+hmJ7v5yNwQDoj6FJA2Msh9NyX9bYj7iUGHb3g5uxdxgLZYJW5i8fQGxJXBVUe4xxZEFRBdJ5o3G0sK2VMYv/nT/aEQf21jHqAnMDOqblSIW1GGCkkiiW00iX3cVBOM9FYWhLxp5kdJwjcj2ACMLjUfimKEM6iciRGE8GMkYBTBXnr0Qg+wjdahVK1e0iUGnHmJHVnp5MGDxEFDwEng8waiTmaDYORicfVW3Iy8swcHH6C4/HobVTS7IDrNAhJzmwPPQ23xOW3DHCkcm6c0CjwkY5nrdB8sERKnwggByomrODD5CVjBH/li2WfETlnbrC57Ey7TljPtqfVMeBuQjRHmNesBE2rcHAiIeKerSnvx8MKppF9VLZOGpMwmPApFyFsJAzyrLRJmaSfEfWIeXyRD4jcWG3auyR4QrGnjxQRikAPgtRNtGei3Pg8uJh4zy2USX3WIZjWbhABo1MuIP+jv4or2ZV7BGMUbtmgwFjFFwlF+6PHQVL5N2BaBi9KAVGgYrGiyCT/VkF/GY+yyX7JUc+R+DYYwRWBV46ilZguyCNyqJ0jLPnwzxyS24gALx2B4/NVEsiJXG2zseO9vcnRSmeB4IgjfZDpEPc2Zc9CozAkXXzqP4EMSEaReodh/cUDaQdglysH3ILgYjm4GEJRLiHR9Uq11HZjtgEpB9qrv9oFsIlQMzgrtCAsacfT/dApAo/TlMtiZzB3FMZdRvHHQAwD9FCVCHViqHQL6p2xGbFDKDLG+VsnkDayzsAZKAIMu7OZdG/UISV4V0V/UvKqIjRSTIYRjaOHqSkahAJtR/8D+bj4fFHsC6oJREDOUyr+ACeFuHD46gkjkjr+Kg2kZVUHePjhAOFwgzcmi2MNNWPXRNwB3AkEH1khBeRNocxl0PsGE2a+GJAJpK4Y0IKz8c02qYYNUsFrhp/mHLO/cKMZWQ8DweGSKDKL1Yu0BSI8TEFT/EocZtqdPH5HoguYQl53CJIF/zDGwGdYIxmUK4oJKPo25IMLKojiYtWoiubzxZCoXAU1wU4IZd89BynqShRTHfixiR+tuF4DsVwoKJ5iPVA5HBDv+zg4jmC6HDnQX3y0QJI5EH5GGJt4D8LDkuU45AsG7HTQbWibAw+lcdvSZlCspp9UpZaFk5IZgFKAKMUM6JNzmZRLszB8DwKNC6pagVbRNeTyLx1IHmjIqA4IAAvAB7rCo+7+4+6oz7kujiwh4yKCwAxnBDnkAsTolnXE1ZjQXwAU3MqMg6BfDwTxcv+QS9JxOKSYbtLkAoJkk2bd3Ug7NrUg8grkFK6MYkPaDV0Xo5m4q7C9UXIbWzAhjhXNPuYWFwLAsMkqwDN5JKFe5CEWC6JJwdskqImEQnvyOSjsTjagUQSUZXN5pB4wSUHRqP5cYTPmAvLgpYziWo+FxN0+ZMcAwIUl2F0PoaJj/sQIZnPGDN53StKLJMNaM0ABKeoYfiAu99YLf3u3HhyNOAqQLJJrnBmfLQqzNuiUchUoo8/+O8oyuhRYyXPsrns0UxUBwDMUraraiAAmVYgEEDz6IpQ6hrgeHs8nxmV60z68LkO9WsAkUA3KdTcHufg48nxbAwVcBo6DDBdHkZvPhtVHY76n7I9EXrzUCKo8dFsJhuLq7JLgUFZEF5QXLI9EE5mM9F4wPfVjrdHIsjPKPZwNJmF8J7P59G/sknImV2CwItPJiz8f0UYdlikyyy5AAAAAElFTkSuQmCC"
            alt="Please enable images to view this content" title="Hero Image"
            width="340" style="
            width: 87.5%;
            max-width: 340px;
            color: #FFFFFF; font-size: 13px; margin: 0; padding: 0; outline: none; text-decoration: none; -ms-interpolation-mode: bicubic; border: none; display: block;"/></a></td>
    </tr>

    <!-- SUPHEADER -->
    <!-- Set text color and font family ("sans-serif" or "Georgia, serif") -->
    <tr>
        <td align="center" valign="top" style="border-collapse: collapse; border-spacing: 0; margin: 0; padding: 0; padding-left: 6.25%; padding-right: 6.25%; width: 87.5%; font-size: 14px; font-weight: 400; line-height: 150%; letter-spacing: 2px;
            padding-top: 27px;
            padding-bottom: 0;
            color: #FFFFFF;
            font-family: sans-serif;" class="supheader">
                Halo '. $nama . ' 
        </td>
    </tr>

    <!-- HEADER -->
    <!-- Set text color and font family ("sans-serif" or "Georgia, serif") -->
    <tr>
        <td align="center" valign="top" style="border-collapse: collapse; border-spacing: 0; margin: 0; padding: 0;  padding-left: 6.25%; padding-right: 6.25%; width: 87.5%; font-size: 24px; font-weight: bold; line-height: 130%;
            padding-top: 5px;
            color: #FFFFFF;
            font-family: sans-serif;" class="header">
                Selamat pengajuan pinjaman Anda telah disetujui
        </td>
    </tr>

    <!-- PARAGRAPH -->
    <!-- Set text color and font family ("sans-serif" or "Georgia, serif"). Duplicate all text styles in links, including line-height -->
    <tr>
        <td align="center" valign="top" style="border-collapse: collapse; border-spacing: 0; margin: 0; padding: 0; padding-left: 6.25%; padding-right: 6.25%; width: 87.5%; font-size: 17px; font-weight: 400; line-height: 160%;
            padding-top: 15px; 
            color: #FFFFFF;
            font-family: sans-serif;" class="paragraph">
                Silahkan login untuk mengecek pinjaman Anda<br/>
				
				Hormat Kami, Admin<br/>
				Koperasi PT. Honda Precision Parts Manufacturing
        </td>
    </tr>

    <!-- BUTTON -->
    <!-- Set button background color at TD, link/text color at A and TD, font family ("sans-serif" or "Georgia, serif") at TD. For verification codes add "letter-spacing: 5px;". Link format: http://domain.com/?utm_source={{Campaign-Source}}&utm_medium=email&utm_content={{Button-Name}}&utm_campaign={{Campaign-Name}} -->
    <tr>
        <td align="center" valign="top" style="border-collapse: collapse; border-spacing: 0; margin: 0; padding: 0; padding-left: 6.25%; padding-right: 6.25%; width: 87.5%;
            padding-top: 25px;
            padding-bottom: 5px;" class="button"><a
            href="http://localhost/kopkar/Login_admin/login.php" target="_blank" style="text-decoration: underline;">
                <table border="0" cellpadding="0" cellspacing="0" align="center" style="max-width: 240px; min-width: 120px; border-collapse: collapse; border-spacing: 0; padding: 0;"><tr><td align="center" valign="middle" style="padding: 12px 24px; margin: 0; text-decoration: underline; border-collapse: collapse; border-spacing: 0; border-radius: 4px; -webkit-border-radius: 4px; -moz-border-radius: 4px; -khtml-border-radius: 4px;"
                    bgcolor="#E9703E"><a target="_blank" style="text-decoration: underline;
                    color: #FFFFFF; font-family: sans-serif; font-size: 17px; font-weight: 400; line-height: 120%;"
                    href="http://localhost/kopkar/Login_admin/login.php">
                        Login
                    </a>
            </td></tr></table></a>
        </td>
    </tr>

    <!-- LINE -->
    <!-- Set line color -->
    <tr>
        <td align="center" valign="top" style="border-collapse: collapse; border-spacing: 0; margin: 0; padding: 0; padding-left: 6.25%; padding-right: 6.25%; width: 87.5%;
            padding-top: 30px;" class="line"><hr
            color="#565F73" align="center" width="100%" size="1" noshade style="margin: 0; padding: 0;" />
        </td>
    </tr>
<!-- End of WRAPPER -->
</table>

<!-- End of SECTION / BACKGROUND -->
</td></tr></table>

</body>
</html>';
    

     //Server settings
    $mail->SMTPDebug = 0;                                 // Enable verbose debug output
    $mail->isSMTP();                                      // Set mailer to use SMTP
    $mail->Host = 'smtp.gmail.com';  // Specify main and backup SMTP servers
    $mail->SMTPAuth = true;                               // Enable SMTP authentication
    $mail->Username = 'angga.reno99@gmail.com';             // SMTP username
    $mail->Password = 'reno1996';                           // SMTP password
    $mail->SMTPSecure = 'tls';                            // Enable TLS encryption, `ssl` also accepted
	$mail->Port = 587; // or 587


    $mail->SetFrom("scnd.anggareno@gmail.com", "Admin Kopkar");
    $mail->AddReplyTo("scnd.anggareno@gmail.com", "Admin Kopkar");
    $mail->AddAddress($userEmail); // you can't pass php variables in single goutes like '$userEmail'. 
    $mail->Subject = $subject;
    $mail->MsgHTML($content);
    $mail->IsHTML(true);
 if(!$mail->Send()) {
    echo "Mailer Error: " . $mail->ErrorInfo;
 } else {
    echo 'Message has been sent to '; 
    echo $userEmail;
    echo "<br/>";
    echo "<a href='hal_admin_data_customer.php' class='btn btn-sm btn-primary'>Kembali</a>";
    $id_anggota = $_GET['kd'];

$query = ("UPDATE tb_pengajuan SET status = 'Di setujui' WHERE id_pengajuan='$id_anggota'");
$result = mysqli_query($connect, $query)or die(mysqli_error());
if ($query) {
    echo "<script>alert('Data Pengajuan Berhasil diproses!'); window.location = '../admin/hal_admin_data_pengajuan.php'</script>";
} else {
    echo "<script>alert('Data Pengajuan Gagal diproses!'); window.location = '../admin/hal_admin_data_pengajuan.php'</script>";
}
 }
	} catch (Exception $e) {
	    echo 'Message could not be sent. Mailer Error: ', $mail->ErrorInfo;
}
}
?>