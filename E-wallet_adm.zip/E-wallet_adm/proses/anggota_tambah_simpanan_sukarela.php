<?php

include "koneksi.php";
$id_simpanan = $_POST['id_simpanan'];
$id_anggota = $_POST['id_anggota'];
$nama = $_POST['nama'];
$jenis_simpanan = $_POST['jenis_simpanan'];
$tanggal = $_POST['tanggal'];
$nominal = $_POST['nominal'];
$file_struk = $_FILES['file_struk']['name'];
$status = 'Pending';

$file_tmp = $_FILES['file_struk']['tmp_name'];

move_uploaded_file($file_tmp, '../admin/foto/' . $file_struk);

$query = ("INSERT INTO tb_simpanan (id_simpanan, id_admin, id_anggota, nama, jenis_simpanan, tanggal, nominal, file_struk, status)"
        . "VALUES ('$id_simpanan', "
        . "'A02', "
        . "'$id_anggota', "
		. "'$nama', "
        . "'$jenis_simpanan', "
		. "'$tanggal', "
        . "'$nominal', "
		. "'$file_struk', "
        . "'$status')");
$result = mysqli_query($connect, $query)or die(mysqli_error());
if ($query) {
    echo "<script>alert('Data Simpanan Berhasil diajukan!'); window.location = '../admin/hal_anggota_data_simpanan_sukarela.php'</script>";
} else {
    echo "<script>alert('Data Simpanan Gagal diajukan!'); window.location = '../admin/hal_anggota_data_simpanan_sukarela.php'</script>";
}
?>