<?php

include "koneksi.php";
$id_anggota = $_POST['id_anggota'];
$password = $_POST['password'];
$nama = $_POST['nama'];
$departemen = $_POST['departemen'];
$ttl = $_POST['ttl'];
$alamat = $_POST['alamat'];
$no_telp = $_POST['no_telp'];
$email = $_POST['email'];
$tanggal_registrasi = $_POST['tanggal_registrasi'];

$query = ("UPDATE tb_anggota SET id_anggota='$id_anggota', password='$password', nama='$nama', departemen='$departemen',
 ttl='$ttl', alamat='$alamat', no_telp='$no_telp', email='$email', tanggal_registrasi='$tanggal_registrasi' WHERE id_anggota='$id_anggota'");
$result = mysqli_query($connect, $query)or die(mysqli_error());
if ($query) {
    echo "<script>alert('Data Anggota Berhasil diubah!'); window.location = '../admin/hal_anggota_data_profil_anggota.php'</script>";
} else {
    echo "<script>alert('Data Anggota Gagal diubah!'); window.location = 'edit.php?hal=edit&kd=$kary_id</script>";
}
?>