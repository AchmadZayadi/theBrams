<?php

include "koneksi.php";
$id_peminjaman = $_POST['id_peminjaman'];
$id_pengajuan = $_POST['id_pengajuan'];
$id_admin = $_POST['id_admin'];
$id_anggota = $_POST['id_anggota'];
$tanggal_peminjaman = $_POST['tanggal_peminjaman'];
$jenis_pinjaman = $_POST['jenis_pinjaman'];
$nominal = $_POST['nominal'];
$audit = $_POST['audit'];
$tk = $_POST['tk'];
$biaya_perbulan = $_POST['biaya_perbulan'];
$status = 'Di proses';

$query = ("INSERT INTO tb_peminjaman (id_peminjaman, id_pengajuan, id_admin, id_anggota, tanggal_peminjaman, jenis_pinjaman, nominal, biaya_perbulan, status)"
        . "VALUES ('$id_peminjaman', "
        . "'$id_pengajuan', "
        . "'$id_admin', "
        . "'$id_anggota', "
        . "'$tanggal_peminjaman', "
        . "'$jenis_pinjaman', "
		. "'$nominal', "
		. "'$biaya_perbulan', "
        . "'$status')");
$result = mysqli_query($connect, $query)or die(mysqli_error());



$query = ("UPDATE tb_pengajuan SET status = 'Di setujui' WHERE id_pengajuan='$id_pengajuan'");
$result = mysqli_query($connect, $query)or die(mysqli_error());


$jumlah = $tk - $nominal;

$query2 = ("UPDATE tb_audit SET tabungan_koperasi = '$jumlah' WHERE id_audit='$audit'");
$result2 = mysqli_query($connect, $query2)or die(mysqli_error());


if ($query) {
    echo "<script>alert('Data Peminjaman Berhasil dimasukkan!'); window.location = '../admin/hal_admin_data_angsuran.php'</script>";
} else {
    echo "<script>alert('Data Peminjaman Gagal dimasukan!'); window.location = '../admin/hal_admin_data_peminjaman.php'</script>";
}
?>