<?php

include "koneksi.php";
$id_anggota = $_GET['kd'];
$id_anggota2 = $_GET['hal'];

$query = ("UPDATE tb_peminjaman SET status = 'Lunas' WHERE id_pengajuan='$id_anggota'");
$result = mysqli_query($connect, $query)or die(mysqli_error());

$query2 = ("UPDATE tb_angsuran SET status = 'Lunas' WHERE id_peminjaman='$id_anggota2'");
$result2 = mysqli_query($connect, $query2)or die(mysqli_error());

$query3 = ("UPDATE tb_pengajuan SET status = 'Lunas' WHERE id_pengajuan='$id_anggota'");
$result4 = mysqli_query($connect, $query3)or die(mysqli_error());

if ($query) {
    echo "<script>alert('Data Peminjaman Telah Lunas!'); window.location = '../admin/hal_admin_data_peminjaman.php'</script>";
} else {
    echo "<script>alert('Data Peminjaman Gagal diproses!'); window.location = '../admin/hal_admin_data_peminjaman.php'</script>";
}
?>