<?php
//insert.php

 include("koneksi.php");
 
 if(isset($_POST['submit']))
 {
    $ekstensi_diperbolehkan = array('png', 'jpg', 'pdf');
 $id_anggota = $_POST["id_anggota"];
 $password = $_POST["password"];
 $nama = $_POST["nama"];
 $departemen = $_POST["departemen"];
 $ttl = $_POST["ttl"];
 $alamat = $_POST["alamat"];
 $no_telp = $_POST["no_telp"];
 $email = $_POST["email"];
 $file_ktp = $_FILES['file_ktp']['name'];
 $file_id_card = $_FILES['file_id_card']['name'];
 $file_kk = $_FILES['file_kk']['name'];
 $file_slip_gaji = $_FILES['file_slip_gaji']['name'];
 $file_foto = $_FILES['file_foto']['name'];
 $tanggal_registrasi = $_POST["tanggal_registrasi"];
 $status = 'Pending';
    
        $file_tmp = $_FILES['file_ktp']['tmp_name'];
        $file_tmp2 = $_FILES['file_id_card']['tmp_name'];
		$file_tmp3 = $_FILES['file_kk']['tmp_name'];
		$file_tmp4 = $_FILES['file_slip_gaji']['tmp_name'];
		$file_tmp5 = $_FILES['file_foto']['tmp_name'];
		
                move_uploaded_file($file_tmp, '../admin/foto/' . $file_ktp);
                move_uploaded_file($file_tmp2, '../admin/foto/' . $file_id_card);
				move_uploaded_file($file_tmp3, '../admin/foto/' . $file_kk);
                move_uploaded_file($file_tmp4, '../admin/foto/' . $file_slip_gaji);
				move_uploaded_file($file_tmp5, '../admin/foto/' . $file_foto);
				
                $query = "INSERT INTO tb_anggota(id_anggota,  password, id_admin, nama, departemen, ttl, alamat, no_telp, email, file_ktp, file_id_card, file_kk, file_slip_gaji, file_foto, tanggal_registrasi, status)
 VALUES ('$id_anggota', '$password', 'A01', '$nama', '$departemen', '$ttl', '$alamat', '$no_telp', '$email', '$file_ktp', '$file_id_card', '$file_kk', '$file_slip_gaji', '$file_foto', '$tanggal_registrasi', '$status')";
               $result = mysqli_query($connect, $query)or die(mysqli_error());
        if ($query) {
        echo "<script>alert('Data Registrasi Berhasil dimasukkan!'); window.location = '../Login_admin/login.php'</script>";
    } else {
        echo "<script>alert('Data Registrasi Gagal dimasukan!'); window.location = '../Login_admin/login.php'</script>";
    }
           
}
?>