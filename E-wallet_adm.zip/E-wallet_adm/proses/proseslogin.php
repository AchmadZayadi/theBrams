<?php

include "koneksi.php";

$username = $_POST['username'];
$pass = $_POST['pass'];

$login = mysqli_query($connect, "SELECT * FROM tb_admin WHERE username  = '$username' AND password='$pass'");

$ketemu = mysqli_num_rows($login);
$row = mysqli_fetch_array($login);
if ($ketemu > 0) {
	
    session_start();
   $_SESSION['nama'] = $username;
    $_SESSION['level'] = $row['jabatan'];
	$_SESSION['idadm'] = $row['id_admin'];
    $username = $_SESSION['nama'];
    $level = $_SESSION['level'];
	
    $pass = $_SESSION['pwd'];
    if ($row['jabatan'] == "admin") {
        header('location: ../admin/hal_admin.php');
    } 
} else {
	echo "<script>alert('Username atau Password Anda tidak benar!'); window.location = '../index.php'</script>";
	}
?>
