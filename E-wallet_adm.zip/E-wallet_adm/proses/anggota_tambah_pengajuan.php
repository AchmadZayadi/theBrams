<?php

include "koneksi.php";
//$id_admin = $_POST ['id_admin'];
$id_pengajuan = $_POST['id_pengajuan'];
$id_anggota = $_POST['id_anggota'];
$status_perkawinan = $_POST['status_perkawinan'];
$no_rekening = $_POST['no_rekening'];
$bank = $_POST['bank'];
$atas_nama = $_POST['atas_nama'];
$jenis_pinjaman = $_POST['jenis_pinjaman'];
$jangka_waktu = $_POST['jangka_waktu'];
$nominal = $_POST['nominal'];
$biaya_perbulan = $_POST['biaya_perbulan'];
$tanggal_pengajuan = $_POST['tanggal_pengajuan'];
$bunga = $_POST['bunga'];
$status = 'Pending';

$query = ("INSERT INTO tb_pengajuan (id_pengajuan, id_anggota, status_perkawinan, no_rek, bank, atas_nama, jenis_pinjaman, jangka_waktu, nominal, biaya_perbulan, tanggal_pengajuan, status)"
        . "VALUES ('$id_pengajuan', "
        . "'$id_anggota', "
        . "'$status_perkawinan', "
		. "'$no_rekening', "
        . "'$bank', "
		. "'$atas_nama', "
        . "'$jenis_pinjaman', "
		. "'$jangka_waktu', "
		. "'$nominal', "
		. "'$biaya_perbulan', "
		. "'$tanggal_pengajuan', "
        . "'$status')");
$result = mysqli_query($connect, $query)or die(mysqli_error());



if ($query) {
    echo "<script>alert('Data Pengajuan Berhasil dimasukkan!' ); window.location = '../admin/hal_anggota_data_pengajuan.php'</script>";
} else {
    echo "<script>alert('Data Pengajuan Gagal dimasukan!'); window.location = 'index.php'</script>";
}
?>