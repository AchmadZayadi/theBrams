<?php
include "koneksi.php";
$id_anggota = $_GET['kd'];

$query = ("DELETE FROM tb_anggota WHERE id_anggota ='$id_anggota'");
$result = mysqli_query($connect, $query)or die(mysqli_error());
if ($query){
	echo "<script>alert('Data Berhasil dihapus!'); window.location = '../admin/hal_admin_data_anggota.php'</script>";	
} else {
	echo "<script>alert('Data Gagal dihapus!'); window.location = '../admin/hal_admin_data_anggota.php'</script>";	
}
?>