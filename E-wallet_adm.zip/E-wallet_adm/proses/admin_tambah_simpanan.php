<?php

include "koneksi.php";
$id_simpanan = $_POST['id_simpanan'];
//$id_peminjaman = $_POST['id_peminjaman'];
$id_admin = $_POST['id_admin'];
$id_anggota = $_POST['id_anggota'];
$nama = $_POST['nama'];
$jenis_simpanan = $_POST['jenis_simpanan'];
$tanggal = $_POST['tanggal'];
$nominal = $_POST['nominal'];
$status = 'Approve';

$tampil3 = ("SELECT tabungan_koperasi as total from tb_audit ORDER BY id_audit DESC limit 1");
                                    $result3 = mysqli_query($connect, $tampil3)or die(mysqli_error());
									$row3 = mysqli_fetch_array($result3);
									$tabungan_kooprasi = $row3['total'];
									

$total_tabungan = $tabungan_kooprasi + $nominal;

$query = ("INSERT INTO tb_simpanan (id_simpanan, id_admin, id_anggota, nama, jenis_simpanan, tanggal, nominal, status)"
        . "VALUES ('$id_simpanan', "
        . "'$id_admin', "
        . "'$id_anggota', "
        . "'$nama', "
        . "'$jenis_simpanan', "
        . "'$tanggal', "
        . "'$nominal', "
		. "'$status')");
$result = mysqli_query($connect, $query)or die(mysqli_error());
	
 $query3 = "SELECT max(id_audit) as maxid FROM tb_audit";
                        $hasil = mysqli_query($connect, $query3)or die(mysqli_error());
                        $hslidmax = mysqli_fetch_array($hasil);
                        $idmax = $hslidmax['maxid']; 
                        $nourut = (int) substr($idmax, 1,6);

                        $nourut++;

                        $newID = sprintf('%03s', $nourut);

$query2 = ("INSERT INTO tb_audit (id_audit, id_admin, id_peminjaman, id_simpanan, id_anggota, uang_masuk, tanggal_transaksi, tabungan_koperasi)"
        . "VALUES ('$newID', "
		. "'$id_admin', "
        . "'PM001', "
        . "'$id_simpanan', "
		. "'$id_anggota', "
        . "'$nominal', "
        . "'$tanggal', "
		. "'$total_tabungan')");
if ($query) {
$result2 = mysqli_query($connect, $query2)or die(mysqli_error());
    echo "<script>alert('Data Simpanan Berhasil dimasukkan!'); window.location = '../admin/hal_admin_data_simpanan.php'</script>";
} else {
    echo "<script>alert('Data Simpanan Gagal dimasukan!'); window.location = '../admin/hal_admin_data_simpanan.php'</script>";
}

?>