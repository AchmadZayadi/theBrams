<?php

include "koneksi.php";
$id_simpanan = $_POST['id_simpanan'];
$id_admin = $_POST['id_admin'];
$id_anggota = $_POST['id_anggota'];
$nama = $_POST['nama'];
$jenis_simpanan = $_POST['jenis_simpanan'];
$tanggal = $_POST['tanggal'];
$nominal = $_POST['nominal'];
$status = 'Pending';

$query = ("UPDATE tb_simpanan SET id_simpanan='$id_simpanan', id_admin='$id_admin', id_anggota='$id_anggota', nama='$nama', jenis_simpanan='$jenis_simpanan', tanggal='$tanggal', nominal='$nominal'
 WHERE id_simpanan='$id_simpanan'");
$result = mysqli_query($connect, $query)or die(mysqli_error());
if ($query) {
    echo "<script>alert('Data Simpanan Berhasil diubah!'); window.location = '../admin/hal_admin_data_simpanan.php'</script>";
} else {
    echo "<script>alert('Data Simpanan Gagal diubah!'); window.location = 'hal_admin_edit_simpanan.php?hal=edit&kd=$id_peminjaman</script>";
}
?>