<?php
include "koneksi.php";
$id_pengajuan = $_GET['kd'];

$query = ("DELETE FROM tb_pengajuan WHERE id_pengajuan ='$id_pengajuan'");
$result = mysqli_query($connect, $query)or die(mysqli_error());
if ($query){
	echo "<script>alert('Data Berhasil dihapus!'); window.location = '../admin/hal_admin_data_pengajuan.php'</script>";	
} else {
	echo "<script>alert('Data Gagal dihapus!'); window.location = '../admin/hal_admin_data_pengajuan.php'</script>";	
}
?>