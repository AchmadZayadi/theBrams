<?php

include "koneksi.php";
$id_pengumuman = $_POST['id_pengumuman'];
$judul = $_POST['judul'];
$deskripsi = $_POST['deskripsi'];
$tanggal = $_POST['tanggal'];
$waktu = $_POST['waktu'];
$lokasi = $_POST['lokasi'];

$query = ("INSERT INTO tb_pengumuman (id_pengumuman, id_admin, judul, deskripsi, tanggal, waktu, lokasi)"
        . "VALUES ('$id_pengumuman', "
        . "'A01', "
        . "'$judul', "
        . "'$deskripsi', "
        . "'$tanggal', "
        . "'$waktu', "
        . "'$lokasi')");
$result = mysqli_query($connect, $query)or die(mysqli_error());
if ($query) {
    echo "<script>alert('Data Pengumuman Berhasil dimasukkan!'); window.location = '../Admin/hal_ketua_data_pengumuman.php'</script>";
} else {
    echo "<script>alert('Data Pengumuman Gagal dimasukkan!'); window.location = '../Admin/hal_ketua_data_pengumuman.php'</script>";
}
?>