<?php
include "koneksi.php";
$id_pengumuman = $_GET['kd'];

$query = ("DELETE FROM tb_pengumuman WHERE id_pengumuman ='$id_pengumuman'");
$result = mysqli_query($connect, $query)or die(mysqli_error());
if ($query){
	echo "<script>alert('Data Berhasil dihapus!'); window.location = '../admin/hal_ketua_data_pengumuman.php'</script>";	
} else {
	echo "<script>alert('Data Gagal dihapus!'); window.location = '../admin/hal_ketua_data_pengumuman.php'</script>";	
}
?>