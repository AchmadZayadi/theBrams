<?php

include "koneksi.php";
$id_implementasi = $_POST['id_implementasi'];
$id_kop = $_POST['id_kop'];
$periode = $_POST['periode'];
$jml_kelompok = $_POST['jml_kelompok'];
$jml_sub_kelompok = $_POST['jml_sub_kelompok'];
$laki = $_POST['laki'];
$perempuan = $_POST['perempuan'];
$tahapan_keluarga = $_POST['tahapan_keluarga'];
$pra_ks = $_POST['pra_ks'];
$ks1 = $_POST['ks1'];
$ks2 = $_POST['ks2'];
$ks3 = $_POST['ks3'];
$ks3_plus = $_POST['ks3_plus'];
$simpanan_anggota_modal_rp = $_POST['simpanan_anggota_modal_rp'];
$simpanan_pokok = $_POST['simpanan_pokok'];
$simpanan_wajib = $_POST['simpanan_wajib'];
$simpanan_anggota_kewajiban = $_POST['simpanan_anggota_kewajiban'];
$simpanan_sukarela = $_POST['simpanan_sukarela'];
$simpanan_berjangka = $_POST['simpanan_berjangka'];
$simpanan_khusus = $_POST['simpanan_khusus'];
$simpanan_tanggung_renteng = $_POST['simpanan_tanggung_renteng'];
$pinjaman_ydsm = $_POST['pinjaman_ydsm'];
$pinjaman_anggota_realisasi = $_POST['pinjaman_anggota_realisasi'];
$omzet_pinjaman = $_POST['omzet_pinjaman'];
$os_pinjaman = $_POST['os_pinjaman'];
$npl_pesen = $_POST['npl_pesen'];
$npl_rp = $_POST['npl_rp'];
$jenis_usaha = $_POST['jenis_usaha'];
$perdaganagan_kecil = $_POST['perdaganagan_kecil'];
$kerajinan_industri_kecil = $_POST['kerajinan_industri_kecil'];
$pertanian_perikanan = $_POST['pertanian_perikanan'];
$usaha_baru = $_POST['usaha_baru'];
$shu = $_POST['shu'];

$query = ("INSERT INTO implementasi_kop (id_implementasi, id_kop, periode, jml_kelompok, jml_sub_kelompok, laki_laki, perempuan, tahapan_keluarga, pra_ks, ks1, ks2, ks3, ks3_plus, simpanan_anggota_modal(Rp.),simpanan_pokok, simpanan_wajib, simpanan_anggota(Kewajiban_Rp.), simpanan_sukarela, simpanan_berjangka, simpanan_khusus, simpanan_tanggung_renteng, pinjaman_ydsm, pinjaman_anggota_realisasi, omzet_pinjaman, os_pinjaman, npl_%, npl_rp, jenis-usaha, perdaganagan_kecil, kerajinan_industri_kecil, pertanian_perikanan, usaha_baru, shu )"
        . "VALUES ('$id_implementasi', "
        . "'$id_kop', "
        . "'$periode', "
        . "'$jml_kelompok', "
        . "'$jml_sub_kelompok', "
        . "'$laki', "
        . "'$perempuan', "
        . "'$tahapan_keluarga', "
        . "'$pra_ks', "
        . "'$ks1', "
        . "'$ks2', "
        . "'$ks3', "
        . "'$ks3_plus', "
        . "'$simpanan_anggota_modal_rp', "
        . "'$simpanan_pokok', "
        . "'$simpanan_wajib', "
        . "'$simpanan_anggota_kewajiban', "
        . "'$simpanan_sukarela', "
        . "'$simpanan_berjangka', "
        . "'$simpanan_khusus', "
        . "'$simpanan_tanggung_renteng', "
        . "'$pinjaman_ydsm', "
        . "'$pinjaman_anggota_realisasi', "
        . "'$omzet_pinjaman', "
        . "'$os_pinjaman', "
        . "'$npl_pesen', "
        . "'$npl_rp', "
        . "'$jenis_usaha', "
        . "'$perdaganagan_kecil', "
        . "'$kerajinan_industri_kecil', "
        . "'$pertanian_perikanan', "
        . "'$usaha_baru', "
        . "'$shu')");
$result = mysqli_query($connect, $query)or die(mysqli_error());
if ($query) {
    echo "<script>alert('Data Admin Berhasil dimasukkan!'); window.location = '../Admin/hal_ketua_data_admin.php'</script>";
} else {
    echo "<script>alert('Data Admin Gagal dimasukan!'); window.location = 'hal_ketua_data_admin.php'</script>";
}
?>