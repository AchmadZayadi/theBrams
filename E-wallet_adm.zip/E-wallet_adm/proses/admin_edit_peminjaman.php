<?php

include "koneksi.php";
$id_peminjaman = $_POST['id_peminjaman'];
$id_pengajuan = $_POST['id_pengajuan'];
$id_admin = $_POST['id_admin'];
$id_anggota = $_POST['id_anggota'];
$tanggal_peminjaman = $_POST['tanggal_peminjaman'];
$jenis_pinjaman = $_POST['jenis_pinjaman'];
$nominal = $_POST['nominal'];
$biaya_perbulan = $_POST['biaya_perbulan'];
$status = $_POST['status'];

$query = ("UPDATE tb_peminjaman SET id_peminjaman='$id_peminjaman', id_pengajuan='$id_pengajuan', id_admin='$id_admin', id_anggota='$id_anggota', tanggal_peminjaman='$tanggal_peminjaman', jenis_pinjaman='$jenis_pinjaman', nominal='$nominal', biaya_perbulan='$biaya_perbulan', status='$status'
 WHERE id_peminjaman='$id_peminjaman'");
$result = mysqli_query($connect, $query)or die(mysqli_error());
if ($query) {
    echo "<script>alert('Data Peminjaman Berhasil diubah!'); window.location = '../admin/hal_admin_data_peminjaman.php'</script>";
} else {
    echo "<script>alert('Data Peminjaman Gagal diubah!'); window.location = 'hal_admin_edit_peminjaman.php?hal=edit&kd=$id_peminjaman</script>";
}
?>