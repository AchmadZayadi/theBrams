<?php

include "koneksi.php";
$id_simpanan = $_POST['id_simpanan'];
$id_anggota = $_POST['id_anggota'];
$nama = $_POST['nama'];
$jenis_simpanan = $_POST['jenis_simpanan'];
$tanggal = $_POST['tanggal'];
$nominal = $_POST['nominal'];
$file_struk = $_FILES['file_struk']['name'];
$status = 'Approve';

$file_tmp = $_FILES['file_struk']['tmp_name'];

move_uploaded_file($file_tmp, '../admin/foto/' . $file_struk);

$tampil3 = ("SELECT tabungan_koperasi as total from tb_audit ORDER BY id_audit DESC limit 1");
                                    $result3 = mysqli_query($connect, $tampil3)or die(mysqli_error());
									$row3 = mysqli_fetch_array($result3);
									$tabungan_kooprasi = $row3['total'];
									

$total_tabungan = $tabungan_kooprasi + $nominal;

$query = ("INSERT INTO tb_simpanan (id_simpanan, id_admin, id_anggota, nama, jenis_simpanan, tanggal, nominal, file_struk, status)"
        . "VALUES ('$id_simpanan', "
        . "'A02', "
        . "'$id_anggota', "
		. "'$nama', "
        . "'$jenis_simpanan', "
		. "'$tanggal', "
        . "'$nominal', "
		. "'$file_struk', "
        . "'$status')");
		



$query2 = ("UPDATE tb_anggota SET status = 'Approve' WHERE id_anggota='$id_anggota'");
$result2 = mysqli_query($connect, $query2)or die(mysqli_error());
$result = mysqli_query($connect, $query)or die(mysqli_error());

$query3 = "SELECT max(id_audit) as maxid FROM tb_audit";
                        $hasil = mysqli_query($connect, $query3)or die(mysqli_error());
                        $hslidmax = mysqli_fetch_array($hasil);
                        $idmax = $hslidmax['maxid']; 
                        $nourut = (int) substr($idmax, 1,6);

                        $nourut++;

                        $newID = sprintf('%03s', $nourut);

$query4 = ("INSERT INTO tb_audit (id_audit, id_admin, id_peminjaman, id_simpanan, id_anggota, uang_masuk, tanggal_transaksi, tabungan_koperasi)"
        . "VALUES ('$newID', "
		. "'A01', "
        . "'PM001', "
        . "'$id_simpanan', "
		. "'$id_anggota', "
        . "'$nominal', "
        . "'$tanggal', "
		. "'$total_tabungan')");
$result4 = mysqli_query($connect, $query4)or die(mysqli_error());

if ($result) {
    echo "<script>alert('Data Simpanan Berhasil dimasukkan!'); window.location = '../Login_admin/login.php'</script>";
} else {
    echo "<script>alert('Data Simpanan Gagal diajukan!'); window.location = '../admin/hal_anggota_data_simpanan_sukarela.php'</script>";
}
?>