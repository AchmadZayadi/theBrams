<?php

include "koneksi.php";
$id_pengumuman = $_POST['id_pengumuman'];
$judul = $_POST['judul'];
$deskripsi = $_POST['deskripsi'];
$tanggal = $_POST['tanggal'];
$waktu = $_POST['waktu'];
$lokasi = $_POST['lokasi'];

$query = ("UPDATE tb_pengumuman SET id_pengumuman='$id_pengumuman', "
        . "id_admin='A01', "
		. "judul='$judul', "
		. "deskripsi='$deskripsi', "
        . "tanggal='$tanggal', "
		. "waktu='$waktu', "
		. "lokasi='$lokasi'
 WHERE id_pengumuman ='$id_pengumuman'");
$result = mysqli_query($connect, $query)or die(mysqli_error());
if ($query) {
    echo "<script>alert('Data Pengumuman Berhasil diubah!'); window.location = '../admin/hal_ketua_data_pengumuman.php'</script>";
} else {
    echo "<script>alert('Data Pengumuman Gagal diubah!'); window.location = 'ketua_edit_pengumuman.php?hal=edit&kd=$id</script>";
}
?>