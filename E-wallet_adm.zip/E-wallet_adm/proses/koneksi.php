<?php
$dbhost = 'localhost'; 
$dbuser = 'cvdutani_e-walle';
$dbpass = 'Kk^==cY)HS.U';
$dbname = 'cvdutani_e-wallet';

$connect = mysqli_connect($dbhost,$dbuser,$dbpass,$dbname) or die('koneksi gagal');
?>