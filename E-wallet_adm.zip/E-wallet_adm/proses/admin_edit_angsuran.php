<?php

include "koneksi.php";
$id_angsuran = $_POST['id_angsuran'];
$id_peminjaman = $_POST['id_peminjaman'];
$id_admin = $_POST['id_admin'];
$id_anggota = $_POST['id_anggota'];
$nama = $_POST['nama'];
$tanggal = $_POST['tanggal'];
$jenis_pinjaman = $_POST['jenis_pinjaman'];
$nominal = 'nominal';
$biaya_perbulan = $_POST['biaya_perbulan'];
$jumlah_angsuran = $_POST['jumlah_angsuran'];
$status = $_POST['status'];

$query = ("UPDATE tb_angsuran SET id_angsuran='$id_angsuran', id_peminjaman='$id_peminjaman', id_admin='$id_admin', id_anggota='$id_anggota', nama='$nama', tanggal='$tanggal', jenis_pinjaman='$jenis_pinjaman', nominal='$nominal', biaya_perbulan='$biaya_perbulan', jumlah_angsuran='$jumlah_angsuran', status='$status'
 WHERE id_angsuran='$id_angsuran'");
$result = mysqli_query($connect, $query)or die(mysqli_error());
if ($query) {
    echo "<script>alert('Data Angsuran Berhasil diubah!'); window.location = '../admin/hal_admin_data_angsuran.php'</script>";
} else {
    echo "<script>alert('Data Angsuran Gagal diubah!'); window.location = 'hal_admin_edit_angsuran.php?hal=edit&kd=$id_simpanan</script>";
}
?>