<?php
include "koneksi.php";
$id_simpanan 	= $_GET['kd'];

$query = ("DELETE FROM tb_simpanan WHERE id_simpanan ='$id_simpanan'");
$result = mysqli_query($connect, $query)or die(mysqli_error());
if ($query){
	echo "<script>alert('Data Berhasil dihapus!'); window.location = '../admin/hal_admin_data_simpanan.php'</script>";	
} else {
	echo "<script>alert('Data Gagal dihapus!'); window.location = '../admin/hal_admin_data_simpanan.php'</script>";	
}
?>