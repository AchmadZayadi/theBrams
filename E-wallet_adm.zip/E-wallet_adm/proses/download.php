<?php

// Tentukan folder file yang boleh di download
include './koneksi.php';
$namafile = $_GET['file'];


    $contenttype = "application/force-download";
    header("Content-Type: " . $contenttype);
    header("Content-Disposition: attachment; filename=\"" . basename($namafile) . "\";");
    readfile($namafile);
    exit();

?>