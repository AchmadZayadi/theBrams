<?php
	 include_once "connect.php";

	 class usr{}
	 
	 $id_user = $_POST["id_user"];
	 $nama_pel = $_POST["nama"];
	 $alamat = $_POST["alamat"];
	 $email = $_POST["email"];
	 $no_telp = $_POST["telepon"];
	 $password = $_POST["password"];
	 $confirm_password = $_POST["confirm_password"];

	 if ((empty($id_user))) {
	 	$response = new usr();
	 	$response->success = 0;
	 	$response->message = "Kolom Nomer Pelangan tidak boleh kosong";
	 	die(json_encode($response));
	 } else if ((empty($confirm_password)) || $password != $confirm_password) {
	 	$response = new usr();
	 	$response->success = 0;
	 	$response->message = "Saldo anda tidak cukup bro!";
	 	die(json_encode($response));
	 }  else {
		 
		 		$sql2 = "UPDATE `tb_customer` SET `nama` = '$nama_pel', `alamat` = '$alamat', `email` = '$email', `username` = '$no_telp' WHERE `tb_customer`.`id` = '$id_user';";
            	$query3 = mysqli_query($con,$sql2);

		 		if ($query3){
		 			$response = new usr();
		 			$response->success = 1;
		 			$response->message = "Edit berhasil, Terimakasih.";
		 			die(json_encode($response));

		 		} else {
		 			$response = new usr();
		 			$response->success = 0;
		 			$response->message = "Edit gagal!";
		 			die(json_encode($response));
		 		}
	 }

	 mysqli_close($con);

?>	