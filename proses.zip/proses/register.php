<?php
	 include_once "connect.php";

	 class usr{}
	 
	 $query22 = "SELECT max(id) as maxid FROM tb_customer";
                        $hasil = mysqli_query($con, $query22)or die(mysqli_error());
                        $hslidmax = mysqli_fetch_array($hasil);
                        $idmax = $hslidmax['maxid']; 
                        $nourut = (int) substr($idmax, 2,4);

                        $nourut++;

                        $newID = 'CS' . sprintf('%03s', $nourut);
                        
                        $query21 = "SELECT max(id) as maxid FROM tb_customer";
                        $hasil = mysqli_query($con, $query21)or die(mysqli_error());
                        $hslidmax = mysqli_fetch_array($hasil);
                        $idmax = $hslidmax['maxid']; 
                        $nourut = (int) substr($idmax, 2,4);

                        $nourut++;

                        $newID2 = 'WL' . sprintf('%03s', $nourut);

	 $username = $_POST["telepon"];
	 $nama = $_POST["nama"];
	 $alamat = $_POST["alamat"];
	 $email = $_POST["email"];
	 $password = $_POST["password"];
	 $confirm_password = $_POST["confirm_password"];

	 if ((empty($username))) {
	 	$response = new usr();
	 	$response->success = 0;
	 	$response->message = "Kolom username tidak boleh kosong";
	 	die(json_encode($response));
	 } else if ((empty($password))) {
	 	$response = new usr();
	 	$response->success = 0;
	 	$response->message = "Kolom password tidak boleh kosong";
	 	die(json_encode($response));
	 } else if ((empty($confirm_password)) || $password != $confirm_password) {
	 	$response = new usr();
	 	$response->success = 0;
	 	$response->message = "Konfirmasi password tidak sama";
	 	die(json_encode($response));
	 } else {
		 if (!empty($username) && $password == $confirm_password){
		 	$num_rows = mysqli_num_rows(mysqli_query($con, "SELECT * FROM tb_customer WHERE username='".$username."'"));

		 	if ($num_rows == 0){
		 	   $query = mysqli_query($con, "INSERT INTO tb_customer (id,nama, alamat,email, username, password) VALUES('".$newID."','".$nama."','".$alamat."','".$email."','".$username."','".$password."')");

               $query2 = mysqli_query($con, "INSERT INTO `tb_wallet` (`id_wallet`, `id_user`, `saldo`) VALUES ('".$newID2."', '".$newID."', '0')");

		 		if ($query){
		 			$response = new usr();
		 			$response->success = 1;
		 			$response->message = "Register berhasil, silahkan login.";
		 			die(json_encode($response));

		 		}if($query2){
		 		    $response = new usr();
		 			$response->success = 1;
		 			$response->message = "Register berhasil, silahkan login.";
		 			die(json_encode($response));
		 		    
		 		} 
		 		else {
		 			$response = new usr();
		 			$response->success = 0;
		 			$response->message = "Terjadi Kesalahan";
		 			die(json_encode($response));
		 		}
		 	} else {
		 		$response = new usr();
		 		$response->success = 0;
		 		$response->message = "Username sudah ada";
		 		die(json_encode($response));
		 	}
		 }
	 }

	 mysqli_close($con);

?>	