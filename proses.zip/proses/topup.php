<?php
	 include_once "connect.php";

	 class usr{}
	 
	 $query22 = "SELECT max(id_topup) as maxid FROM tb_topup";
                        $hasil = mysqli_query($con, $query22)or die(mysqli_error());
                        $hslidmax = mysqli_fetch_array($hasil);
                        $idmax = $hslidmax['maxid']; 
                        $nourut = (int) substr($idmax, 2,4);

                        $nourut++;

                        $newID = 'TP' . sprintf('%03s', $nourut);
                        	
		$path = "bukti_bayar/$newID.png";
		
		$actualpath = "http://cv-dutaniaga.com/proses/$path";

	$image = $_POST['foto_struk'];
    $id_wallet = $_POST['id_wallet'];
    $id_user = $_POST['id_pel'];
    $total_transaksi = $_POST['total_transaksi'];
	$date = date('Y-m-d H:i:s');
	$status = "Pending";


	 if ((empty($id_user))) {
	 	$response = new usr();
	 	$response->success = 0;
	 	$response->message = "Kolom id tidak boleh kosong";
	 	die(json_encode($response));
	 } else if ((empty($image))) {
	 	$response = new usr();
	 	$response->success = 0;
	 	$response->message = "Silahkan Upload Bukti Bayar";
	 	die(json_encode($response));
	 }  else {
		 
		 		$query = mysqli_query($con, "INSERT INTO `tb_topup` (`id_topup`, `id_wallet`, `id_user`, `total_transaksi`, `foto_struk`, `status`) VALUES ('$newID', '$id_wallet', '$id_user', '$total_transaksi','$actualpath', '$status');");

		 		if ($query){
		 			$response = new usr();
		 			$response->success = 1;
		 			file_put_contents($path,base64_decode($image));
		 			$response->message = "Pembayaran berhasil, Terimakasih.";
		 			die(json_encode($response));

		 		} else {
		 			$response = new usr();
		 			$response->success = 0;
		 			$response->message = "pembayaran gagal!";
		 			die(json_encode($response));
		 		}
	 }

	 mysqli_close($con);

?>	