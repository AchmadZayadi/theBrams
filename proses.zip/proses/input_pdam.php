<?php
	 include_once "connect.php";

	 class usr{}
	 
	 $query22 = "SELECT max(id_transaksi) as maxid FROM tb_transaksi";
                        $hasil = mysqli_query($con, $query22)or die(mysqli_error());
                        $hslidmax = mysqli_fetch_array($hasil);
                        $idmax = $hslidmax['maxid']; 
                        $nourut = (int) substr($idmax, 2,4);

                        $nourut++;

                        $newID = 'TR' . sprintf('%03s', $nourut);
     $newno = '0110' + $nourut++;
     $id_cus = $_POST["id_pel"];
	 $id_pel = $_POST["id_cus"];
	 $tagihan = $_POST["tagihan"];
	 $id_admin = 'ADM001';
	 $status = 'Success';
	 $id_ewallet = $_POST["id_wallet"];
     $ket = 'Pembayaran PDAM';
	 $date = date('Y-m-d H:i:s');
	 
	$query2 = "SELECT * FROM tb_wallet where id_wallet ='$id_ewallet'";
                        $hasil2 = mysqli_query($con, $query2)or die(mysqli_error());
                        $row = mysqli_fetch_array($hasil2);
	 					$saldo = $row['saldo'];
	 
	 if ((empty($id_pel))) {
	 	$response = new usr();
	 	$response->success = 0;
	 	$response->message = "Kolom Nomer Pelangan tidak boleh kosong";
	 	die(json_encode($response));
	 } else if ($saldo < $tagihan) {
	 	$response = new usr();
	 	$response->success = 0;
	 	$response->message = "Saldo anda tidak cukup bro!";
	 	die(json_encode($response));
	 }  else {
		 
		 		$query = mysqli_query($con, "INSERT INTO `tb_transaksi` (`id_transaksi`, `id_admin`, `id_user`, `id_produk`, `id_wallet`, `no_transaksi`, `total_harga`,`status`,`keterangan`,`tgl_transaksi`) VALUES ('$newID', '$id_admin ', '$id_cus', 'PAM001', '$id_ewallet', '$id_pel', '$tagihan','$status','$ket','$date');");
		 		
		 		
		 		$sql2 = "UPDATE tb_wallet set saldo = saldo - '$tagihan' WHERE id_wallet ='$id_ewallet'";
            	$query3 = mysqli_query($con,$sql2);


		 		if ($query){
		 			$response = new usr();
		 			$response->success = 1;
		 			$response->message = "Pembayaran berhasil, Terimakasih.";
		 			die(json_encode($response));

		 		} else {
		 			$response = new usr();
		 			$response->success = 0;
		 			$response->message = "pembayaran gagal!";
		 			die(json_encode($response));
		 		}
	 }

	 mysqli_close($con);

?>	