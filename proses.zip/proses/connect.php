<?php 
define('host', 'localhost');
define('user', 'cvdutani_e-walle');
define('pass', 'Kk^==cY)HS.U');
define('db', 'cvdutani_e-wallet');

$con = mysqli_connect(host, user, pass, db) or die('Unable to Connect');
?>