<?php
include_once "connect.php";

$id_ewallet = $_POST["id_wallet"];
$sql = "SELECT * FROM tb_customer INNER JOIN tb_wallet ON tb_customer.id=tb_wallet.id_user WHERE id_wallet = '$id_ewallet'";

$result = $con->query($sql);

if ($result->num_rows > 0) {
 
 while($row[] = $result->fetch_assoc()) {
 
    $json_arr = array("status"=>"true","message"=>"Data fetched successfully!","data"=> $row);
    
 }
 
} else {
 echo "No Results Found.";
}
echo json_encode($json_arr);
?>